```python
# Custom codes are used for this study.
```

# Import the libraries


```python
import rdkit
import pandas as pd
import sys
import math
import collections
from math import log
from scipy import stats
from rdkit import Chem, DataStructs
import numpy as np
import seaborn as sns #pip install seaborn
import matplotlib #pip install matplotlib
import matplotlib.pyplot as plt
import sklearn #pip install scikit-learn
from sklearn.decomposition import PCA
from collections import Counter # count freq
from operator import itemgetter
from rdkit.Chem.Scaffolds import MurckoScaffold
from rdkit.Chem.Fingerprints import FingerprintMols
from rdkit.Chem import Descriptors
from rdkit.Chem import AllChem
from rdkit.Chem import Draw
from matplotlib_venn import venn2
from matplotlib_venn import venn2_unweighted  
from matplotlib import gridspec
import matplotlib.backend_tools as mpt
from matplotlib.offsetbox import OffsetImage,AnnotationBbox,TextArea
import matplotlib.backend_tools as mpt
import matplotlib.backends
from tqdm import tqdm
import numpy
from scipy.cluster.hierarchy import dendrogram, linkage
```


```python
from matplotlib.offsetbox import OffsetImage,AnnotationBbox,TextArea
import pylab
from pylab import xticks
from mpl_toolkits import mplot3d
from matplotlib import (
    _api, backend_tools as tools, cbook, colors, text,
    transforms, widgets, get_backend, is_interactive, rcParams)
import matplotlib_tools as mpt
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import matplotlib.patches as mpatches
# pip install lazypredict-nightly yaparak sorun çozuldu
import lazypredict
import lazypredict.Supervised
from lazypredict.Supervised import LazyClassifier
from lazypredict.Supervised import LazyRegressor
from sklearn.utils import all_estimators
from sklearn.model_selection import train_test_split
import glob
import random
import base64
import pandas as pd

from PIL import Image
from io import BytesIO
from IPython.display import HTML
```


```python
from rdkit.Chem import rdDepictor
rdDepictor.SetPreferCoordGen(True)
```


```python
print("User Current Version:-", sys.version)
```

    User Current Version:- 3.12.8 | packaged by Anaconda, Inc. | (main, Dec 11 2024, 16:48:34) [MSC v.1929 64 bit (AMD64)]
    

# Import Porphyrin Dataset 


```python
porph = pd.read_csv('porphyrin.csv')
porph.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Molecule ChEMBL ID</th>
      <th>Molecule Name</th>
      <th>Molecule Max Phase</th>
      <th>Molecular Weight</th>
      <th>#RO5 Violations</th>
      <th>AlogP</th>
      <th>Compound Key</th>
      <th>Smiles</th>
      <th>Standard Type</th>
      <th>Standard Relation</th>
      <th>...</th>
      <th>Target Type</th>
      <th>Document ChEMBL ID</th>
      <th>Source ID</th>
      <th>Source Description</th>
      <th>Document Journal</th>
      <th>Document Year</th>
      <th>Cell ChEMBL ID</th>
      <th>Properties</th>
      <th>Action Type</th>
      <th>Standard Text Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>CHEMBL1325592</td>
      <td>PROTOPORPHYRIN</td>
      <td>-1.00</td>
      <td>562.67</td>
      <td>2.00</td>
      <td>7.50</td>
      <td>SID50106857</td>
      <td>C=CC1=C(C)c2cc3[nH]c(cc4nc(cc5[nH]c(cc1n2)c(C)...</td>
      <td>Potency</td>
      <td>'='</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CHEMBL441738</td>
      <td>AFAMELANOTIDE</td>
      <td>4.00</td>
      <td>1646.87</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NDP-MSH</td>
      <td>CCCC[C@H](NC(=O)[C@H](CO)NC(=O)[C@H](Cc1ccc(O)...</td>
      <td>EC50</td>
      <td>'='</td>
      <td>...</td>
      <td>SINGLE PROTEIN</td>
      <td>CHEMBL1136069</td>
      <td>1.00</td>
      <td>Scientific Literature</td>
      <td>Bioorg Med Chem Lett</td>
      <td>2003.00</td>
      <td>CHEMBL3307715</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CHEMBL441738</td>
      <td>AFAMELANOTIDE</td>
      <td>4.00</td>
      <td>1646.87</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NDP-MSH</td>
      <td>CCCC[C@H](NC(=O)[C@H](CO)NC(=O)[C@H](Cc1ccc(O)...</td>
      <td>EC50</td>
      <td>'='</td>
      <td>...</td>
      <td>SINGLE PROTEIN</td>
      <td>CHEMBL1136069</td>
      <td>1.00</td>
      <td>Scientific Literature</td>
      <td>Bioorg Med Chem Lett</td>
      <td>2003.00</td>
      <td>CHEMBL3307715</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>CHEMBL71</td>
      <td>CHLORPROMAZINE</td>
      <td>4.00</td>
      <td>318.87</td>
      <td>0.00</td>
      <td>4.89</td>
      <td>Chlorpromazine</td>
      <td>CN(C)CCCN1c2ccccc2Sc2ccc(Cl)cc21</td>
      <td>IC50</td>
      <td>'='</td>
      <td>...</td>
      <td>SINGLE PROTEIN</td>
      <td>CHEMBL1136167</td>
      <td>1.00</td>
      <td>Scientific Literature</td>
      <td>Bioorg Med Chem Lett</td>
      <td>2003.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>CHEMBL500593</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>622.72</td>
      <td>2.00</td>
      <td>6.31</td>
      <td>6</td>
      <td>C=Cc1c(C)c2cc3nc(c4c5[nH]c(cc6nc(cc1[nH]2)C(C)...</td>
      <td>ED50</td>
      <td>'='</td>
      <td>...</td>
      <td>CELL-LINE</td>
      <td>CHEMBL1155723</td>
      <td>1.00</td>
      <td>Scientific Literature</td>
      <td>J Nat Prod</td>
      <td>2001.00</td>
      <td>CHEMBL3308035</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 47 columns</p>
</div>




```python
porph['Smiles'][0]
```




    'C=CC1=C(C)c2cc3[nH]c(cc4nc(cc5[nH]c(cc1n2)c(C)c5CCC(=O)O)C(CCC(=O)O)=C4C)c(C)c3C=C'




```python
#porph['Assay Description'].unique().tolist()
```


```python
len(porph) #12405 rows
```




    12405




```python
# Remove molecules related to porphyria disease found in dataset but not a porphyrin molecule itself!
molecule_ids_to_remove = [
    'CHEMBL1535', 'CHEMBL1222250', 'CHEMBL550348', 'CHEMBL71',
    'CHEMBL1201481', 'CHEMBL4297760', 'CHEMBL4594265', 'CHEMBL5275624', 'CHEMBL441738']

# Remove them !
porph = porph[~porph['Molecule ChEMBL ID'].isin(molecule_ids_to_remove)]
```


```python
# number of molecules in the initial dataset
len(porph)
```




    8084




```python
# include only IC50 results
porph=porph[ porph['Standard Type'] == "IC50"]
```


```python
len(porph)
```




    778




```python
# remove replicates
porph=porph[~porph.duplicated(['Molecule ChEMBL ID', 'Document ChEMBL ID'], keep='first')]
```


```python
len(porph)
```




    342




```python
# remove missing values
porph=porph.dropna(subset=['Smiles'])
```


```python
len(porph)
```




    336




```python
porph['Standard Type'].unique()
```




    array(['IC50'], dtype=object)




```python
porph['Standard Units'].unique() #only 1 diff types of activity unit values
```




    array(['nM', 'ug.mL-1', nan], dtype=object)




```python
porph= porph[(porph['Standard Units'] == 'nM') | (porph['Standard Units'].isna())]
```


```python
len(porph)
```




    317




```python
#porph['Assay Description'].unique().tolist()
```


```python
# Assay types used...
porph['Assay Type'].unique().tolist()
```




    ['B', 'A', 'F', 'T', nan]




```python
pd.set_option('display.max_rows', None)  # display all rows
pd.set_option('display.max_columns', None)  # display all columns
```


```python
porph=porph.reset_index()
```


```python
len(porph)
```




    317




```python
porph.isnull().sum() #
```




    index                           0
    Molecule ChEMBL ID              0
    Molecule Name                 286
    Molecule Max Phase            306
    Molecular Weight                0
    #RO5 Violations                16
    AlogP                          16
    Compound Key                    0
    Smiles                          0
    Standard Type                   0
    Standard Relation               5
    Standard Value                  2
    Standard Units                  2
    pChEMBL Value                  51
    Data Validity Comment         298
    Comment                       310
    Uo Units                        2
    Ligand Efficiency BEI         288
    Ligand Efficiency LE          292
    Ligand Efficiency LLE         292
    Ligand Efficiency SEI         292
    Potential Duplicate             0
    Assay ChEMBL ID                 0
    Assay Description               0
    Assay Type                      6
    BAO Format ID                   6
    BAO Label                       6
    Assay Organism                 31
    Assay Tissue ChEMBL ID        317
    Assay Tissue Name             317
    Assay Cell Type                73
    Assay Subcellular Fraction    317
    Assay Parameters              317
    Assay Variant Accession       317
    Assay Variant Mutation        317
    Target ChEMBL ID                6
    Target Name                     6
    Target Organism                48
    Target Type                     6
    Document ChEMBL ID              6
    Source ID                       6
    Source Description              6
    Document Journal               10
    Document Year                   9
    Cell ChEMBL ID                 96
    Properties                    248
    Action Type                   307
    Standard Text Value           317
    dtype: int64




```python
random=Chem.MolFromSmiles(porph['Smiles'].iloc[12])# Visiualize a molecule randomly chosen
rdDepictor.Compute2DCoords(random)
```




    0




```python
#visiualize a molecule randomly
random
```




    
![png](output_30_0.png)
    




```python
top_10_research_subject = porph['Assay Description'].value_counts().head(10)

```


```python

top_10_research_subject = porph['Assay Description'].value_counts().head(10)


def limit_words(description):
    return ' '.join(description.split()[:7])


top_10_table = pd.DataFrame({
    'Assay Description': top_10_research_subject.index,
    'Count': top_10_research_subject.values
})


top_10_table['Assay Description'] = top_10_table['Assay Description'].apply(limit_words)


print(top_10_table)
```

                                       Assay Description  Count
    0        Cytotoxicity against human HCT116 cell line     17
    1  Phototoxicity against human A549 cells assesse...     11
    2  Phototoxicity against human ECA109 cells asses...      9
    3  Photosensitizing activity against human HeLa c...      9
    4  Cytotoxicity in rat R3230AC cells irradiated with      7
    5         Dark toxicity in human A549 cells assessed      7
    6           Dark toxicity in human HepG2 cells after      6
    7  Phototoxicity against human HaCaT cells assess...      6
    8  Cytotoxicity against human Bel7402 cells after 48      6
    9  Antileishmanial activity against promastigote ...      6
    


```python
top_3_values = porph['Standard Type'].value_counts().head(3)
top_3_values
```




    Standard Type
    IC50    317
    Name: count, dtype: int64



# Frequency of assays


```python
# Function of the most frequently worked structure
def freq(struc):
    col_list =  Counter(list(struc['Molecule ChEMBL ID']))
    res = dict(sorted(col_list.items(), key = itemgetter(1), reverse = True)[:7])
    return res
freq(porph)
```




    {'CHEMBL65606': 7,
     'CHEMBL500576': 6,
     'CHEMBL1956500': 5,
     'CHEMBL1325592': 5,
     'CHEMBL2170855': 4,
     'CHEMBL207155': 3,
     'CHEMBL353314': 3}




```python
x=plt.bar(range(len(freq(porph))), list(freq(porph).values()), align='center',color ="#F8C8DC")
plt.xticks(range(len(freq(porph))), freq(porph).keys()) 
plt.xticks(rotation=40,fontsize='9',horizontalalignment='right')
plt.yticks(fontsize='9')
plt.xlabel('ChemBL IDs of Molecules',  color='black',
   fontsize='11', horizontalalignment='center')
plt.ylabel('Frequency ',  color='black',
   fontsize='11', horizontalalignment='center')
plt.grid(False);
```


    
![png](output_36_0.png)
    



```python
freq_data = freq(porph)
keys = list(freq_data.keys())[:2]
smiles_list = list(porph.loc[porph['Molecule ChEMBL ID'].isin(keys), 'Smiles'])

# Molekülleri çizme
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]
img = Draw.MolsToGridImage(molecules[0:2], molsPerRow=2, subImgSize=(200, 200))
```


```python
img
```




    
![png](output_38_0.png)
    



# Activity


```python
# IC50>10000 nM accepted as non-active
```


```python
# assume Standard Value==0 as inactive
porph['Standard Value'] = porph['Standard Value'].fillna(10001)
porph=porph.dropna(subset=['Standard Value'])
```


```python
# Labelling structures as active or non-active (Deep Learning Approach for Discovery of In Silico Drugs for Combating COVID-19)
rating = []
for row in porph["Standard Value"]:
    if row >= 10000 :    rating.append("pIC$_5$$_0$ inactive") 
    elif row < 10000:   rating.append("pIC$_5$$_0$ active")
    else:  rating.append("pIC$_5$$_0$ inactive")

```


```python
# Assign active molecules
porph['activity_status'] = rating
porph[0:3]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Molecule ChEMBL ID</th>
      <th>Molecule Name</th>
      <th>Molecule Max Phase</th>
      <th>Molecular Weight</th>
      <th>#RO5 Violations</th>
      <th>AlogP</th>
      <th>Compound Key</th>
      <th>Smiles</th>
      <th>Standard Type</th>
      <th>...</th>
      <th>Document ChEMBL ID</th>
      <th>Source ID</th>
      <th>Source Description</th>
      <th>Document Journal</th>
      <th>Document Year</th>
      <th>Cell ChEMBL ID</th>
      <th>Properties</th>
      <th>Action Type</th>
      <th>Standard Text Value</th>
      <th>activity_status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>16</td>
      <td>CHEMBL268410</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1279.63</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7</td>
      <td>CC1=C(C(COC(=O)C23C[C@H]4C[C@@H](C2)C[C@@H](C3...</td>
      <td>IC50</td>
      <td>...</td>
      <td>CHEMBL1126254</td>
      <td>1.00</td>
      <td>Scientific Literature</td>
      <td>J Med Chem</td>
      <td>1992.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
    </tr>
    <tr>
      <th>1</th>
      <td>39</td>
      <td>CHEMBL4741802</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>813.95</td>
      <td>3.00</td>
      <td>7.97</td>
      <td>3a</td>
      <td>CCCCCCOC(C)c1c(C)c2cc3nc(c(CC(=O)N[C@@H](CC(=O...</td>
      <td>IC50</td>
      <td>...</td>
      <td>CHEMBL4706542</td>
      <td>1.00</td>
      <td>Scientific Literature</td>
      <td>Eur J Med Chem</td>
      <td>2020.00</td>
      <td>CHEMBL3307651</td>
      <td>TIME = 48.0 hr</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
    </tr>
    <tr>
      <th>2</th>
      <td>40</td>
      <td>CHEMBL2111186</td>
      <td>TALAPORFIN</td>
      <td>3.00</td>
      <td>711.77</td>
      <td>3.00</td>
      <td>5.95</td>
      <td>Talaporfin</td>
      <td>C=Cc1c(C)c2cc3nc(c(CC(=O)N[C@@H](CC(=O)O)C(=O)...</td>
      <td>IC50</td>
      <td>...</td>
      <td>CHEMBL4706542</td>
      <td>1.00</td>
      <td>Scientific Literature</td>
      <td>Eur J Med Chem</td>
      <td>2020.00</td>
      <td>CHEMBL3307762</td>
      <td>TIME = 48.0 hr</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 49 columns</p>
</div>



# pIC50 calculation of Compounds


```python
result = []
for value in porph['Standard Value']:
    if value < 0:
        solution_log=0
    elif value==0 : 
        solution_log=0
    elif value=='': 
        solution_log=0
    else:
        solution_log=round(math.log(value*(10**-9),10)*-1,2)
    result.append(solution_log)   
    
porph["pIC$_5$$_0$"]= result
porph[0:3]

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Molecule ChEMBL ID</th>
      <th>Molecule Name</th>
      <th>Molecule Max Phase</th>
      <th>Molecular Weight</th>
      <th>#RO5 Violations</th>
      <th>AlogP</th>
      <th>Compound Key</th>
      <th>Smiles</th>
      <th>Standard Type</th>
      <th>Standard Relation</th>
      <th>...</th>
      <th>Document ChEMBL ID</th>
      <th>Source ID</th>
      <th>Source Description</th>
      <th>Document Journal</th>
      <th>Document Year</th>
      <th>Cell ChEMBL ID</th>
      <th>Properties</th>
      <th>Action Type</th>
      <th>Standard Text Value</th>
      <th>pIC$_5$$_0$</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>CHEMBL1325592</td>
      <td>PROTOPORPHYRIN</td>
      <td>-1.00</td>
      <td>562.67</td>
      <td>2.00</td>
      <td>7.50</td>
      <td>SID50106857</td>
      <td>C=CC1=C(C)c2cc3[nH]c(cc4nc(cc5[nH]c(cc1n2)c(C)...</td>
      <td>Potency</td>
      <td>'='</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CHEMBL441738</td>
      <td>AFAMELANOTIDE</td>
      <td>4.00</td>
      <td>1646.87</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NDP-MSH</td>
      <td>CCCC[C@H](NC(=O)[C@H](CO)NC(=O)[C@H](Cc1ccc(O)...</td>
      <td>EC50</td>
      <td>'='</td>
      <td>...</td>
      <td>CHEMBL1136069</td>
      <td>1.00</td>
      <td>Scientific Literature</td>
      <td>Bioorg Med Chem Lett</td>
      <td>2003.00</td>
      <td>CHEMBL3307715</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7.92</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CHEMBL441738</td>
      <td>AFAMELANOTIDE</td>
      <td>4.00</td>
      <td>1646.87</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NDP-MSH</td>
      <td>CCCC[C@H](NC(=O)[C@H](CO)NC(=O)[C@H](Cc1ccc(O)...</td>
      <td>EC50</td>
      <td>'='</td>
      <td>...</td>
      <td>CHEMBL1136069</td>
      <td>1.00</td>
      <td>Scientific Literature</td>
      <td>Bioorg Med Chem Lett</td>
      <td>2003.00</td>
      <td>CHEMBL3307715</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7.12</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 48 columns</p>
</div>




```python
# pIC50 z-score calculation
porph['z_score'] = stats.zscore(porph['pIC$_5$$_0$'])
porph_cleaned = porph[(porph['z_score'] < 3) & (porph['z_score'] > -3)]
porph_cleaned.reset_index(drop=True, inplace=True)
```


```python
sns.scatterplot(x='Molecular Weight',y='pIC$_5$$_0$',hue='activity_status', data=porph,palette="RdPu")
sns.color_palette("mako", as_cmap=True)
plt.grid(False);
```


    
![png](output_47_0.png)
    



```python
sns.jointplot(
    x='Molecular Weight', 
    y='pIC$_5$$_0$', 
    hue='activity_status', 
    data=porph, 
    palette="crest", 
    kind="kde", 
    fill=True
    
);
```


    
![png](output_48_0.png)
    



```python
plt.figure(figsize=(3,4))
sns.countplot(x='activity_status', data=porph, palette="RdPu", edgecolor='grey')
plt.xlabel('Bioactivity Type', fontsize=11)
plt.ylabel('Frequency', fontsize=11)
plt.grid(False)
plt.savefig('ratio_active.png', dpi=600)
;
```




    ''




    
![png](output_49_1.png)
    



```python
percentage = (porph['activity'] == "1").mean() * 100
print(f"Percentage of 'activity' == 1: {percentage:.2f}%")

```

    Percentage of 'activity' == 1: 66.56%
    


```python
count = porph['activity'].eq("1").sum()
print(f"Count of 'activity' == '1': {count}")
```

    Count of 'activity' == '1': 211
    


```python
percentage = (porph['activity_status'] == "pIC$_5$$_0$ active").mean() * 100
print(f"Percentage of 'activity' == 1: {percentage:.2f}%") 
```

    Percentage of 'activity' == 1: 66.56%
    


```python
percentage = (porph['activity_status'] == "pIC$_5$$_0$ inactive").mean() * 100
print(f"Percentage of 'activity' == 1: {percentage:.2f}%") 
```

    Percentage of 'activity' == 1: 33.44%
    


```python
count_ = porph['activity_status'].eq("pIC$_5$$_0$ inactive").sum()
print(f"Count of 'activity' == 'pIC$_5$$_0$ inactive': {count_}")
```

    Count of 'activity' == 'pIC$_5$$_0$ inactive': 106
    


```python
plt.figure(figsize=(3.5, 5.5))
sns.boxplot(x = 'activity_status', y = 'pIC$_5$$_0$', data = porph, color="#1f6357")
plt.xlabel('Bioactivity class', fontsize=14)
plt.ylabel("$pIC_{50} value$", fontsize=12, fontweight='bold');
```


    
![png](output_55_0.png)
    


# Lipinski Rule of Five


```python
def calculate_ro5_properties(smiles):
    """
    Test if input molecule (SMILES) fulfills Lipinski's rule of five.

    Parameters
    ----------
    smiles : str
        SMILES for a molecule.

    Returns
    -------
    pandas.Series
        Molecular weight, number of hydrogen bond acceptors/donor and logP value
        and Lipinski's rule of five compliance for input molecule.
    """
    # RDKit molecule from SMILES
    molecule = Chem.MolFromSmiles(smiles)
    # Calculate Ro5-relevant chemical properties
    molecular_weight = Descriptors.ExactMolWt(molecule)
    n_hba = Descriptors.NumHAcceptors(molecule)
    n_hbd = Descriptors.NumHDonors(molecule)
    logp = Descriptors.MolLogP(molecule)
    # Check if Ro5 conditions fulfilled
    conditions = [molecular_weight <= 500, n_hba <= 10, n_hbd <= 5, logp <= 5]
    ro5_fulfilled = sum(conditions) >= 3
    # Return True if no more than one out of four conditions is violated
    return pd.Series(
        [molecular_weight, n_hba, n_hbd, logp, ro5_fulfilled],
        index=["molecular_weight", "n_hba", "n_hbd", "logp", "ro5_fulfilled"],
    )
```


```python
porph=porph.dropna(subset=['Smiles'])
```


```python
ro5_properties = porph["Smiles"].apply(calculate_ro5_properties)
ro5_properties.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>molecular_weight</th>
      <th>n_hba</th>
      <th>n_hbd</th>
      <th>logp</th>
      <th>ro5_fulfilled</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1278.69</td>
      <td>12</td>
      <td>4</td>
      <td>14.60</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>813.39</td>
      <td>8</td>
      <td>7</td>
      <td>7.97</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>711.29</td>
      <td>7</td>
      <td>7</td>
      <td>5.95</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>698.37</td>
      <td>6</td>
      <td>5</td>
      <td>9.01</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>630.27</td>
      <td>8</td>
      <td>8</td>
      <td>3.53</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
molecules = pd.concat([porph, ro5_properties], axis=1)
molecules.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Molecule ChEMBL ID</th>
      <th>Molecule Name</th>
      <th>Molecule Max Phase</th>
      <th>Molecular Weight</th>
      <th>#RO5 Violations</th>
      <th>AlogP</th>
      <th>Compound Key</th>
      <th>Smiles</th>
      <th>Standard Type</th>
      <th>...</th>
      <th>Action Type</th>
      <th>Standard Text Value</th>
      <th>activity_status</th>
      <th>pIC$_5$$_0$</th>
      <th>z_score</th>
      <th>molecular_weight</th>
      <th>n_hba</th>
      <th>n_hbd</th>
      <th>logp</th>
      <th>ro5_fulfilled</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>16</td>
      <td>CHEMBL268410</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1279.63</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7</td>
      <td>CC1=C(C(COC(=O)C23C[C@H]4C[C@@H](C2)C[C@@H](C3...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>5.30</td>
      <td>-0.35</td>
      <td>1278.69</td>
      <td>12</td>
      <td>4</td>
      <td>14.60</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>39</td>
      <td>CHEMBL4741802</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>813.95</td>
      <td>3.00</td>
      <td>7.97</td>
      <td>3a</td>
      <td>CCCCCCOC(C)c1c(C)c2cc3nc(c(CC(=O)N[C@@H](CC(=O...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
      <td>3.75</td>
      <td>-1.45</td>
      <td>813.39</td>
      <td>8</td>
      <td>7</td>
      <td>7.97</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>40</td>
      <td>CHEMBL2111186</td>
      <td>TALAPORFIN</td>
      <td>3.00</td>
      <td>711.77</td>
      <td>3.00</td>
      <td>5.95</td>
      <td>Talaporfin</td>
      <td>C=Cc1c(C)c2cc3nc(c(CC(=O)N[C@@H](CC(=O)O)C(=O)...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
      <td>4.85</td>
      <td>-0.67</td>
      <td>711.29</td>
      <td>7</td>
      <td>7</td>
      <td>5.95</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>41</td>
      <td>CHEMBL4744564</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>698.86</td>
      <td>2.00</td>
      <td>9.01</td>
      <td>1</td>
      <td>CCCCCCOC(C)c1c(C)c2cc3nc(c(CC(=O)O)c4[nH]c(cc5...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>5.58</td>
      <td>-0.16</td>
      <td>698.37</td>
      <td>6</td>
      <td>5</td>
      <td>9.01</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>60</td>
      <td>CHEMBL12659</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>630.70</td>
      <td>2.00</td>
      <td>3.53</td>
      <td>12</td>
      <td>CC1=C(C(O)CO)c2cc3nc(cc4[nH]c(cc5[nH]c(cc1n2)c...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
      <td>3.70</td>
      <td>-1.48</td>
      <td>630.27</td>
      <td>8</td>
      <td>8</td>
      <td>3.53</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 56 columns</p>
</div>




```python
# Note that the column "ro5_fulfilled" contains boolean values.
# Thus, we can use the column values directly to subset data.
# Note that ~ negates boolean values.
molecules_ro5_fulfilled = molecules[molecules["ro5_fulfilled"]]
molecules_ro5_violated = molecules[~molecules["ro5_fulfilled"]]

print(f"# compounds in unfiltered data set: {molecules.shape[0]}")
print(f"# compounds in filtered data set: {molecules_ro5_fulfilled.shape[0]}")
print(f"# compounds not compliant with the Ro5: {molecules_ro5_violated.shape[0]}")
# NBVAL_CHECK_OUTPUT

```

    # compounds in unfiltered data set: 317
    # compounds in filtered data set: 46
    # compounds not compliant with the Ro5: 271
    


```python
molecules_ro5_fulfilled.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Molecule ChEMBL ID</th>
      <th>Molecule Name</th>
      <th>Molecule Max Phase</th>
      <th>Molecular Weight</th>
      <th>#RO5 Violations</th>
      <th>AlogP</th>
      <th>Compound Key</th>
      <th>Smiles</th>
      <th>Standard Type</th>
      <th>...</th>
      <th>Action Type</th>
      <th>Standard Text Value</th>
      <th>activity_status</th>
      <th>pIC$_5$$_0$</th>
      <th>z_score</th>
      <th>molecular_weight</th>
      <th>n_hba</th>
      <th>n_hbd</th>
      <th>logp</th>
      <th>ro5_fulfilled</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>11</th>
      <td>263</td>
      <td>CHEMBL337559</td>
      <td>TMPYP4 CHLORIDE</td>
      <td>NaN</td>
      <td>820.66</td>
      <td>2.00</td>
      <td>6.62</td>
      <td>TMPyP4 2H</td>
      <td>C[n+]1ccc(-c2c3nc(c(-c4cc[n+](C)cc4)c4ccc([nH]...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>5.20</td>
      <td>-0.42</td>
      <td>818.20</td>
      <td>2</td>
      <td>2</td>
      <td>-5.36</td>
      <td>True</td>
    </tr>
    <tr>
      <th>12</th>
      <td>288</td>
      <td>CHEMBL344150</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>820.66</td>
      <td>2.00</td>
      <td>6.62</td>
      <td>TMPyP3</td>
      <td>C[n+]1cccc(-c2c3nc(c(-c4ccc[n+](C)c4)c4ccc([nH...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
      <td>4.92</td>
      <td>-0.62</td>
      <td>818.20</td>
      <td>2</td>
      <td>2</td>
      <td>-5.36</td>
      <td>True</td>
    </tr>
    <tr>
      <th>27</th>
      <td>579</td>
      <td>CHEMBL1933798</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1057.10</td>
      <td>2.00</td>
      <td>7.86</td>
      <td>3</td>
      <td>CN(C)/C=C/C(=C\C=[N+](C)C)c1c2nc(c(C(/C=C/N(C)...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>5.52</td>
      <td>-0.20</td>
      <td>1054.49</td>
      <td>6</td>
      <td>2</td>
      <td>-4.12</td>
      <td>True</td>
    </tr>
    <tr>
      <th>33</th>
      <td>623</td>
      <td>CHEMBL210258</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>478.56</td>
      <td>1.00</td>
      <td>7.70</td>
      <td>19</td>
      <td>Oc1cccc(-c2c3nc(cc4ccc([nH]4)c(-c4ccccc4)c4nc(...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>8.97</td>
      <td>2.23</td>
      <td>478.18</td>
      <td>3</td>
      <td>3</td>
      <td>7.70</td>
      <td>True</td>
    </tr>
    <tr>
      <th>39</th>
      <td>788</td>
      <td>CHEMBL2420128</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>490.57</td>
      <td>1.00</td>
      <td>7.80</td>
      <td>4b</td>
      <td>O=Cc1c2nc(c(-c3ccccc3)c3ccc(cc4nc(c(-c5ccccc5)...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
      <td>4.70</td>
      <td>-0.78</td>
      <td>490.18</td>
      <td>3</td>
      <td>2</td>
      <td>7.80</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 56 columns</p>
</div>




```python

def calculate_mean_std(dataframe):
    """
    Calculate the mean and standard deviation of a dataset.

    Parameters
    ----------
    dataframe : pd.DataFrame
        Properties (columns) for a set of items (rows).

    Returns
    -------
    pd.DataFrame
        Mean and standard deviation (columns) for different properties (rows).
    """
    # Generate descriptive statistics for property columns
    stats = dataframe.describe()
    # Transpose DataFrame (statistical measures = columns)
    stats = stats.T
    # Select mean and standard deviation
    stats = stats[["mean", "std"]]
    return stats
```


```python
molecules_ro5_fulfilled_stats = calculate_mean_std(
    molecules_ro5_fulfilled[["molecular_weight", "n_hba", "n_hbd", "logp"]]
)
molecules_ro5_fulfilled_stats
# NBVAL_CHECK_OUTPUT

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mean</th>
      <th>std</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>molecular_weight</th>
      <td>733.34</td>
      <td>255.22</td>
    </tr>
    <tr>
      <th>n_hba</th>
      <td>3.76</td>
      <td>1.83</td>
    </tr>
    <tr>
      <th>n_hbd</th>
      <td>2.22</td>
      <td>0.81</td>
    </tr>
    <tr>
      <th>logp</th>
      <td>2.74</td>
      <td>4.01</td>
    </tr>
  </tbody>
</table>
</div>




```python
molecules_ro5_violated_stats = calculate_mean_std(
    molecules_ro5_violated[["molecular_weight", "n_hba", "n_hbd", "logp"]]
)
molecules_ro5_violated_stats

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mean</th>
      <th>std</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>molecular_weight</th>
      <td>780.40</td>
      <td>204.39</td>
    </tr>
    <tr>
      <th>n_hba</th>
      <td>7.05</td>
      <td>3.43</td>
    </tr>
    <tr>
      <th>n_hbd</th>
      <td>3.99</td>
      <td>2.11</td>
    </tr>
    <tr>
      <th>logp</th>
      <td>8.65</td>
      <td>2.99</td>
    </tr>
  </tbody>
</table>
</div>




```python
def _scale_by_thresholds(stats, thresholds, scaled_threshold):
    """
    Scale values for different properties that have each an individually defined threshold.

    Parameters
    ----------
    stats : pd.DataFrame
        Dataframe with "mean" and "std" (columns) for each physicochemical property (rows).
    thresholds : dict of str: int
        Thresholds defined for each property.
    scaled_threshold : int or float
        Scaled thresholds across all properties.

    Returns
    -------
    pd.DataFrame
        DataFrame with scaled means and standard deviations for each physiochemical property.
    """
    # Raise error if scaling keys and data_stats indicies are not matching
    for property_name in stats.index:
        if property_name not in thresholds.keys():
            raise KeyError(f"Add property '{property_name}' to scaling variable.")
    # Scale property data
    stats_scaled = stats.apply(lambda x: x / thresholds[x.name] * scaled_threshold, axis=1)
    return stats_scaled
```


```python
def _define_radial_axes_angles(n_axes):
    """Define angles (radians) for radial (x-)axes depending on the number of axes."""
    x_angles = [i / float(n_axes) * 2 * math.pi for i in range(n_axes)]
    x_angles += x_angles[:1]
    return x_angles

```


```python
def plot_radar(
    y,
    thresholds,
    scaled_threshold,
    properties_labels,
    y_max=None,
    output_path=None,
):
    """
    Plot a radar chart based on the mean and standard deviation of a data set's properties.

    Parameters
    ----------
    y : pd.DataFrame
        Dataframe with "mean" and "std" (columns) for each physicochemical property (rows).
    thresholds : dict of str: int
        Thresholds defined for each property.
    scaled_threshold : int or float
        Scaled thresholds across all properties.
    properties_labels : list of str
        List of property names to be used as labels in the plot.
    y_max : None or int or float
        Set maximum y value. If None, let matplotlib decide.
    output_path : None or pathlib.Path
        If not None, save plot to file.
    """

    # Define radial x-axes angles -- uses our helper function!
    x = _define_radial_axes_angles(len(y))
    # Scale y-axis values with respect to a defined threshold -- uses our helper function!
    y = _scale_by_thresholds(y, thresholds, scaled_threshold)
    # Since our chart will be circular we append the first value of each property to the end
    y = pd.concat([y, y.head(1)])

    # Set figure and subplot axis
    plt.figure(figsize=(3, 3))
    
    ax = plt.subplot(111, polar=True)

    # Plot data
    ax.fill(x, [scaled_threshold] * len(x),"#DC143C", alpha=0.2)
    ax.plot(x, y["mean"], "#F89880", lw=3, ls="-")
    ax.plot(x, y["mean"] + y["std"], "#E30B5C", lw=2, ls="--")
    ax.plot(x, y["mean"] - y["std"], "#FF10F0", lw=2, ls="-.")

    # From here on, we only do plot cosmetics
    # Set 0° to 12 o'clock
    ax.set_theta_offset(math.pi / 2)
    # Set clockwise rotation
    ax.set_theta_direction(-1)

    # Set y-labels next to 180° radius axis
    ax.set_rlabel_position(180)
    # Set number of radial axes' ticks and remove labels
    plt.xticks(x, [])
    # Get maximal y-ticks value
    if not y_max:
        y_max = int(ax.get_yticks()[-1])
    # Set axes limits
    plt.ylim(0, y_max)
    # Set number and labels of y axis ticks
    plt.yticks(
        range(1, y_max),
        ["5" if i == scaled_threshold else "" for i in range(1, y_max)],
        fontsize=16,
    )

    # Draw ytick labels to make sure they fit properly
    # Note that we use [:1] to exclude the last element which equals the first element (not needed here)
    for i, (angle, label) in enumerate(zip(x[:-1], properties_labels)):
        if angle == 0:
            ha = "center"
        elif 0 < angle < math.pi:
            ha = "left"
        elif angle == math.pi:
            ha = "center"
        else:
            ha = "right"
        ax.text(
            x=angle,
            y=y_max + 1,
            s=label,
            size=16,
            horizontalalignment=ha,
            verticalalignment="center",
        )

    # Add legend relative to top-left plot
    labels = ("mean", "mean + std", "mean - std", "rule of five area")
    ax.legend(labels, loc=(1.1, 0.7), labelspacing=0.3, fontsize=16)

    # Save plot - use bbox_inches to include text boxes
    if output_path:
        plt.savefig(output_path, dpi=300, bbox_inches="tight", transparent=True)

    plt.show()
```


```python
thresholds = {"molecular_weight": 650, "n_hba": 4, "n_hbd": 2, "logp": 5}
scaled_threshold = 5
properties_labels = [
    "Molecular weight (Da) / 100",
    "# HBA / 2",
    "# HBD",
    "LogP",
]
y_max = 8
```


```python
plot_radar(
    molecules_ro5_fulfilled_stats,
    thresholds,
    scaled_threshold,
    properties_labels,
    y_max,
)

plt.show()
```


    
![png](output_70_0.png)
    



```python
thresholds = {"molecular_weight": 730, "n_hba": 8, "n_hbd": 4, "logp": 8}
scaled_threshold = 5
properties_labels = [
    "Molecular weight (Da) / 100",
    "# HBA / 2",
    "# HBD",
    "LogP",
]
y_max = 8
```


```python

plot_radar(
    molecules_ro5_violated_stats,
    thresholds,
    scaled_threshold,
    properties_labels,
    y_max,
)


plt.show()

```


    
![png](output_72_0.png)
    



```python
a=porph[porph.activity_status == "pIC$_5$$_0$ active"]
list1=a['Smiles'].tolist()
list2= molecules_ro5_fulfilled['Smiles'].tolist()

```


```python

A=set(list1)
B=set(list2)
diagram = venn2([A, B],("pIC$_5$$_0$ active","Lipinski Active"),set_colors=("#E37383", "#D8BFD8"))

plt.savefig('lipinski_venn.png', dpi=600)
plt.show()
```


    
![png](output_74_0.png)
    



```python
#Jak2 inhibitor – a jackpot for pharmaceutical industries: a comprehensive computational method in the discovery of new potent Jak2 inhibitorsi
list_inactive=[]
for i in porph['activity_status']:
    if i=='pIC$_5$$_0$ inactive':
        list_inactive.append("0")
    else: list_inactive.append("1")
porph['activity']= list_inactive
```


```python
# Extract intersect dataframe for further analysis
intersect=A.intersection(B)
intersect_cox=porph.loc[porph['Smiles'].isin(intersect)] # there are 296>267 molecules which means there are replicates
intersect_cox [0:3]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Molecule ChEMBL ID</th>
      <th>Molecule Name</th>
      <th>Molecule Max Phase</th>
      <th>Molecular Weight</th>
      <th>#RO5 Violations</th>
      <th>AlogP</th>
      <th>Compound Key</th>
      <th>Smiles</th>
      <th>Standard Type</th>
      <th>...</th>
      <th>Document Journal</th>
      <th>Document Year</th>
      <th>Cell ChEMBL ID</th>
      <th>Properties</th>
      <th>Action Type</th>
      <th>Standard Text Value</th>
      <th>activity_status</th>
      <th>pIC$_5$$_0$</th>
      <th>z_score</th>
      <th>activity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>11</th>
      <td>263</td>
      <td>CHEMBL337559</td>
      <td>TMPYP4 CHLORIDE</td>
      <td>NaN</td>
      <td>820.66</td>
      <td>2.00</td>
      <td>6.62</td>
      <td>TMPyP4 2H</td>
      <td>C[n+]1ccc(-c2c3nc(c(-c4cc[n+](C)cc4)c4ccc([nH]...</td>
      <td>IC50</td>
      <td>...</td>
      <td>J Med Chem</td>
      <td>2001.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>5.20</td>
      <td>-0.42</td>
      <td>1</td>
    </tr>
    <tr>
      <th>27</th>
      <td>579</td>
      <td>CHEMBL1933798</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1057.10</td>
      <td>2.00</td>
      <td>7.86</td>
      <td>3</td>
      <td>CN(C)/C=C/C(=C\C=[N+](C)C)c1c2nc(c(C(/C=C/N(C)...</td>
      <td>IC50</td>
      <td>...</td>
      <td>Bioorg Med Chem Lett</td>
      <td>2012.00</td>
      <td>CHEMBL3307654</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>5.52</td>
      <td>-0.20</td>
      <td>1</td>
    </tr>
    <tr>
      <th>33</th>
      <td>623</td>
      <td>CHEMBL210258</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>478.56</td>
      <td>1.00</td>
      <td>7.70</td>
      <td>19</td>
      <td>Oc1cccc(-c2c3nc(cc4ccc([nH]4)c(-c4ccccc4)c4nc(...</td>
      <td>IC50</td>
      <td>...</td>
      <td>J Med Chem</td>
      <td>2006.00</td>
      <td>CHEMBL3308372</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>8.97</td>
      <td>2.23</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 52 columns</p>
</div>




```python
from rdkit.ML.Descriptors import MoleculeDescriptors
def RDkit_descriptors(smiles):
    mols = [Chem.MolFromSmiles(i) for i in smiles] 
    calc = MoleculeDescriptors.MolecularDescriptorCalculator([x[0] for x in Descriptors._descList])
    desc_names = calc.GetDescriptorNames()
    
    Mol_descriptors =[]
    for mol in mols:
        # add hydrogens to molecules
        mol=Chem.AddHs(mol)
        # Calculate all 200 descriptors for each molecule
        descriptors = calc.CalcDescriptors(mol)
        Mol_descriptors.append(descriptors)
    return Mol_descriptors,desc_names 

# Function call
Mol_descriptors,desc_names = RDkit_descriptors(porph['Smiles'])
```


```python
df_with_200_descriptors = pd.DataFrame(Mol_descriptors,columns=desc_names)
df_with_200_descriptors.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MaxAbsEStateIndex</th>
      <th>MaxEStateIndex</th>
      <th>MinAbsEStateIndex</th>
      <th>MinEStateIndex</th>
      <th>qed</th>
      <th>SPS</th>
      <th>MolWt</th>
      <th>HeavyAtomMolWt</th>
      <th>ExactMolWt</th>
      <th>NumValenceElectrons</th>
      <th>...</th>
      <th>fr_sulfide</th>
      <th>fr_sulfonamd</th>
      <th>fr_sulfone</th>
      <th>fr_term_acetylene</th>
      <th>fr_tetrazole</th>
      <th>fr_thiazole</th>
      <th>fr_thiocyan</th>
      <th>fr_thiophene</th>
      <th>fr_unbrch_alkane</th>
      <th>fr_urea</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>17.80</td>
      <td>17.80</td>
      <td>1.37</td>
      <td>-7.14</td>
      <td>0.07</td>
      <td>75.28</td>
      <td>1279.63</td>
      <td>1184.87</td>
      <td>1278.69</td>
      <td>498</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>15.57</td>
      <td>15.57</td>
      <td>1.15</td>
      <td>-5.88</td>
      <td>0.06</td>
      <td>37.05</td>
      <td>813.95</td>
      <td>758.51</td>
      <td>813.39</td>
      <td>316</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>15.31</td>
      <td>15.31</td>
      <td>0.65</td>
      <td>-5.55</td>
      <td>0.12</td>
      <td>33.12</td>
      <td>711.77</td>
      <td>670.44</td>
      <td>711.29</td>
      <td>272</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>14.34</td>
      <td>14.34</td>
      <td>0.92</td>
      <td>-5.51</td>
      <td>0.10</td>
      <td>38.35</td>
      <td>698.86</td>
      <td>648.46</td>
      <td>698.37</td>
      <td>272</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>13.06</td>
      <td>13.06</td>
      <td>0.67</td>
      <td>-4.68</td>
      <td>0.16</td>
      <td>30.70</td>
      <td>630.70</td>
      <td>592.39</td>
      <td>630.27</td>
      <td>242</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 210 columns</p>
</div>




```python
df_with_200_descriptors['pIC$_5$$_0$'] = porph['pIC$_5$$_0$']
```


```python
porph.corr(numeric_only=True) 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Molecule Max Phase</th>
      <th>Molecular Weight</th>
      <th>#RO5 Violations</th>
      <th>AlogP</th>
      <th>Standard Value</th>
      <th>pChEMBL Value</th>
      <th>Ligand Efficiency BEI</th>
      <th>Ligand Efficiency LE</th>
      <th>Ligand Efficiency LLE</th>
      <th>Ligand Efficiency SEI</th>
      <th>Potential Duplicate</th>
      <th>Source ID</th>
      <th>Document Year</th>
      <th>pIC$_5$$_0$</th>
      <th>z_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>index</th>
      <td>1.00</td>
      <td>-0.70</td>
      <td>-0.16</td>
      <td>-0.06</td>
      <td>-0.08</td>
      <td>0.06</td>
      <td>0.15</td>
      <td>0.35</td>
      <td>0.66</td>
      <td>0.21</td>
      <td>0.26</td>
      <td>NaN</td>
      <td>0.13</td>
      <td>0.22</td>
      <td>0.15</td>
      <td>0.15</td>
    </tr>
    <tr>
      <th>Molecule Max Phase</th>
      <td>-0.70</td>
      <td>1.00</td>
      <td>0.57</td>
      <td>0.69</td>
      <td>-0.08</td>
      <td>-0.42</td>
      <td>0.12</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>-0.47</td>
      <td>0.49</td>
      <td>0.45</td>
      <td>0.45</td>
    </tr>
    <tr>
      <th>Molecular Weight</th>
      <td>-0.16</td>
      <td>0.57</td>
      <td>1.00</td>
      <td>0.37</td>
      <td>0.29</td>
      <td>-0.06</td>
      <td>-0.28</td>
      <td>-0.64</td>
      <td>-0.44</td>
      <td>-0.28</td>
      <td>0.30</td>
      <td>NaN</td>
      <td>-0.06</td>
      <td>-0.20</td>
      <td>-0.19</td>
      <td>-0.19</td>
    </tr>
    <tr>
      <th>#RO5 Violations</th>
      <td>-0.06</td>
      <td>0.69</td>
      <td>0.37</td>
      <td>1.00</td>
      <td>0.17</td>
      <td>-0.00</td>
      <td>-0.43</td>
      <td>0.02</td>
      <td>-0.07</td>
      <td>-0.13</td>
      <td>-0.19</td>
      <td>NaN</td>
      <td>0.09</td>
      <td>0.03</td>
      <td>-0.38</td>
      <td>-0.38</td>
    </tr>
    <tr>
      <th>AlogP</th>
      <td>-0.08</td>
      <td>-0.08</td>
      <td>0.29</td>
      <td>0.17</td>
      <td>1.00</td>
      <td>-0.03</td>
      <td>-0.09</td>
      <td>-0.44</td>
      <td>-0.37</td>
      <td>-0.95</td>
      <td>-0.08</td>
      <td>NaN</td>
      <td>-0.05</td>
      <td>-0.12</td>
      <td>-0.01</td>
      <td>-0.01</td>
    </tr>
    <tr>
      <th>Standard Value</th>
      <td>0.06</td>
      <td>-0.42</td>
      <td>-0.06</td>
      <td>-0.00</td>
      <td>-0.03</td>
      <td>1.00</td>
      <td>-0.59</td>
      <td>-0.16</td>
      <td>-0.19</td>
      <td>0.22</td>
      <td>-0.27</td>
      <td>NaN</td>
      <td>-0.01</td>
      <td>0.03</td>
      <td>-0.20</td>
      <td>-0.20</td>
    </tr>
    <tr>
      <th>pChEMBL Value</th>
      <td>0.15</td>
      <td>0.12</td>
      <td>-0.28</td>
      <td>-0.43</td>
      <td>-0.09</td>
      <td>-0.59</td>
      <td>1.00</td>
      <td>0.31</td>
      <td>0.39</td>
      <td>-0.10</td>
      <td>0.17</td>
      <td>NaN</td>
      <td>-0.03</td>
      <td>0.07</td>
      <td>1.00</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>Ligand Efficiency BEI</th>
      <td>0.35</td>
      <td>NaN</td>
      <td>-0.64</td>
      <td>0.02</td>
      <td>-0.44</td>
      <td>-0.16</td>
      <td>0.31</td>
      <td>1.00</td>
      <td>0.95</td>
      <td>0.60</td>
      <td>0.36</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.33</td>
      <td>0.31</td>
      <td>0.31</td>
    </tr>
    <tr>
      <th>Ligand Efficiency LE</th>
      <td>0.66</td>
      <td>NaN</td>
      <td>-0.44</td>
      <td>-0.07</td>
      <td>-0.37</td>
      <td>-0.19</td>
      <td>0.39</td>
      <td>0.95</td>
      <td>1.00</td>
      <td>0.54</td>
      <td>0.27</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.31</td>
      <td>0.39</td>
      <td>0.39</td>
    </tr>
    <tr>
      <th>Ligand Efficiency LLE</th>
      <td>0.21</td>
      <td>NaN</td>
      <td>-0.28</td>
      <td>-0.13</td>
      <td>-0.95</td>
      <td>0.22</td>
      <td>-0.10</td>
      <td>0.60</td>
      <td>0.54</td>
      <td>1.00</td>
      <td>0.14</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>-0.12</td>
      <td>-0.10</td>
      <td>-0.10</td>
    </tr>
    <tr>
      <th>Ligand Efficiency SEI</th>
      <td>0.26</td>
      <td>NaN</td>
      <td>0.30</td>
      <td>-0.19</td>
      <td>-0.08</td>
      <td>-0.27</td>
      <td>0.17</td>
      <td>0.36</td>
      <td>0.27</td>
      <td>0.14</td>
      <td>1.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.02</td>
      <td>0.17</td>
      <td>0.17</td>
    </tr>
    <tr>
      <th>Potential Duplicate</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Source ID</th>
      <td>0.13</td>
      <td>-0.47</td>
      <td>-0.06</td>
      <td>0.09</td>
      <td>-0.05</td>
      <td>-0.01</td>
      <td>-0.03</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.00</td>
      <td>0.05</td>
      <td>-0.02</td>
      <td>-0.02</td>
    </tr>
    <tr>
      <th>Document Year</th>
      <td>0.22</td>
      <td>0.49</td>
      <td>-0.20</td>
      <td>0.03</td>
      <td>-0.12</td>
      <td>0.03</td>
      <td>0.07</td>
      <td>0.33</td>
      <td>0.31</td>
      <td>-0.12</td>
      <td>0.02</td>
      <td>NaN</td>
      <td>0.05</td>
      <td>1.00</td>
      <td>0.05</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>pIC$_5$$_0$</th>
      <td>0.15</td>
      <td>0.45</td>
      <td>-0.19</td>
      <td>-0.38</td>
      <td>-0.01</td>
      <td>-0.20</td>
      <td>1.00</td>
      <td>0.31</td>
      <td>0.39</td>
      <td>-0.10</td>
      <td>0.17</td>
      <td>NaN</td>
      <td>-0.02</td>
      <td>0.05</td>
      <td>1.00</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>z_score</th>
      <td>0.15</td>
      <td>0.45</td>
      <td>-0.19</td>
      <td>-0.38</td>
      <td>-0.01</td>
      <td>-0.20</td>
      <td>1.00</td>
      <td>0.31</td>
      <td>0.39</td>
      <td>-0.10</td>
      <td>0.17</td>
      <td>NaN</td>
      <td>-0.02</td>
      <td>0.05</td>
      <td>1.00</td>
      <td>1.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_cleaned = df_with_200_descriptors.dropna()
```


```python

# Correlation matrix
plt.figure(figsize=(105,105))
sns.heatmap(df_cleaned.corr(numeric_only=True),annot=True)
plt.xticks(rotation=60) 
# Save the figure
plt.savefig('correlation_matrix_porph.png', bbox_inches='tight', dpi=300)
plt.show()
```


    
![png](output_82_0.png)
    



```python
a = abs(df_cleaned.corr(numeric_only=True)).loc['pIC$_5$$_0$'].sort_values(ascending=False)
a=a.drop('pIC$_5$$_0$')
a
```




    qed                0.34
    fr_Al_COO          0.30
    EState_VSA10       0.28
    fr_COO2            0.28
    fr_COO             0.28
                       ... 
    fr_tetrazole        NaN
    fr_thiazole         NaN
    fr_thiocyan         NaN
    fr_unbrch_alkane    NaN
    fr_urea             NaN
    Name: pIC$_5$$_0$, Length: 210, dtype: float64




```python
# parameters >.25 
selected_features = a[a >= 0.25].index
selected_features
```




    Index(['qed', 'fr_Al_COO', 'EState_VSA10', 'fr_COO2', 'fr_COO', 'SMR_VSA10',
           'TPSA', 'VSA_EState4', 'NOCount', 'NHOHCount', 'HallKierAlpha',
           'NumHDonors'],
          dtype='object')




```python
# parameters >0.1 
selected_features2 = a[a >= 0.1].index
selected_features2
```




    Index(['qed', 'fr_Al_COO', 'EState_VSA10', 'fr_COO2', 'fr_COO', 'SMR_VSA10',
           'TPSA', 'VSA_EState4', 'NOCount', 'NHOHCount', 'HallKierAlpha',
           'NumHDonors', 'NumValenceElectrons', 'HeavyAtomCount', 'VSA_EState2',
           'MolMR', 'Chi1', 'fr_C_O', 'SlogP_VSA7', 'Kappa2', 'Chi2n', 'Chi3n',
           'Chi0', 'EState_VSA1', 'PEOE_VSA14', 'LabuteASA', 'fr_sulfonamd',
           'BertzCT', 'fr_NH1', 'NumHeteroatoms', 'NumHAcceptors', 'Chi0n',
           'Chi1n', 'Chi4n', 'Chi1v', 'Chi0v', 'fr_Nhpyrrole', 'fr_Ar_NH', 'Chi3v',
           'Kappa3', 'Chi2v', 'Kappa1', 'MolWt', 'ExactMolWt', 'Chi4v',
           'HeavyAtomMolWt', 'MaxEStateIndex', 'MaxAbsEStateIndex', 'SlogP_VSA2',
           'fr_allylic_oxid', 'PEOE_VSA7', 'VSA_EState1', 'PEOE_VSA8',
           'NumRotatableBonds', 'fr_Ndealkylation2', 'SlogP_VSA3', 'VSA_EState10',
           'fr_ketone_Topliss', 'fr_ketone', 'SMR_VSA1', 'BCUT2D_MWHI', 'SMR_VSA3',
           'SMR_VSA2', 'fr_amide', 'PEOE_VSA2', 'EState_VSA3', 'fr_aniline',
           'fr_aryl_methyl', 'EState_VSA8', 'AvgIpc', 'VSA_EState6', 'fr_Ar_OH',
           'fr_phenol_noOrthoHbond', 'fr_phenol', 'SMR_VSA7', 'FpDensityMorgan3',
           'PEOE_VSA1', 'BCUT2D_MRLOW', 'FpDensityMorgan2', 'MinPartialCharge',
           'fr_Ar_COO', 'fr_sulfide', 'MaxAbsPartialCharge'],
          dtype='object')




```python
df_selected2 = df_with_200_descriptors[selected_features2]
```


```python
df_selected2['pIC$_5$$_0$'] = porph['pIC$_5$$_0$']
```


```python
# Correlation matrix
plt.figure(figsize=(105,105))
sns.heatmap(df_selected2.corr(numeric_only=True),annot=True)
plt.xticks(rotation=60) 
# Save the figure
plt.savefig('correlation_matrix_porph2.png', bbox_inches='tight', dpi=300)
plt.show()
```


    
![png](output_88_0.png)
    



```python
feature_counts = a[selected_features]
features_list = selected_features.tolist()
# Çubuk grafiği oluşturma
plt.figure(figsize=(5, 3))
sns.barplot(x=features_list, y=feature_counts[features_list], color="#F33A6A")

plt.xlabel('Features')
plt.ylabel('Values')
plt.xticks(rotation=35)
plt.xticks(fontsize=8)
plt.tight_layout()

plt.savefig('Selected.png', dpi=600)
plt.show()
```


    
![png](output_89_0.png)
    



```python
df_selected = df_with_200_descriptors[selected_features]
```


```python
df_selected.isna().sum()
```




    qed              0
    fr_Al_COO        0
    EState_VSA10     0
    fr_COO2          0
    fr_COO           0
    SMR_VSA10        0
    TPSA             0
    VSA_EState4      0
    NOCount          0
    NHOHCount        0
    HallKierAlpha    0
    NumHDonors       0
    dtype: int64




```python
# quantitative estimation of drug-likeness (qed)
porph['qed'] = df_selected['qed'].values
porph['fr_Al_COO'] = df_selected['fr_Al_COO'].values
```


```python
# Jointplot
g = sns.jointplot(
    x='qed', 
    y='pIC$_5$$_0$', 
    hue='activity_status', 
    data=porph, 
    palette="RdPu", 
    kind="kde", 
    fill=True
)
sns.move_legend(g.ax_joint, loc='upper left', fontsize=8)
# Boyut ayarla
g.fig.set_size_inches(4.5,4.5)
# Remove grid lines
g.ax_joint.grid(False)  # Main plot
g.ax_marg_x.grid(False)  # Marginal plot for x-axis
g.ax_marg_y.grid(False)  # Marginal plot for y-axis

plt.savefig('activity.png', dpi=600)
# Göster
plt.show()

```


    
![png](output_93_0.png)
    



```python
plt.figure(figsize=(5, 3))
sns.kdeplot(porph['pIC$_5$$_0$'],  fill=True,color="#FFC0CB")
# Set spine thickness

ax = plt.gca()  
ax.spines['top'].set_color('#F2D2BD')
ax.spines['right'].set_color('#F2D2BD')
ax.spines['left'].set_color('#F2D2BD')
ax.spines['bottom'].set_color('#F2D2BD')


plt.grid(False)
plt.savefig('distrubution.png', dpi=600)
plt.show()
```


    
![png](output_94_0.png)
    



```python
sns.scatterplot(x='fr_Al_COO',y='pIC$_5$$_0$',hue='activity_status', data=porph,palette="crest")
sns.color_palette("mako", as_cmap=True);
```


    
![png](output_95_0.png)
    


# TSNE


```python
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt


pca = PCA(n_components=2)
principal_components = pca.fit_transform(df_selected )

plt.figure(figsize=(6, 6))
plt.scatter(principal_components[:, 0], principal_components[:, 1], alpha=0.5)
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.title('PCA of Porphyrin Chemical Space')
plt.grid(False)
plt.savefig('pca_porphyrin.png', dpi=600)
plt.show()
```


    
![png](output_97_0.png)
    



```python
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

# Apply PCA for dimensionality reduction
pca = PCA(n_components=2)
pca_result = pca.fit_transform(df_selected)

# Visualize
plt.scatter(pca_result[:, 0], pca_result[:, 1])
plt.xlabel('PCA 1')
plt.ylabel('PCA 2')
plt.title('Chemical Space of Porphyrins')
plt.show()

```


    
![png](output_98_0.png)
    



```python
#https://github.com/PatWalters/workshop/blob/master/predictive_models/2_visualizing_chemical_space.ipynb
def fp_list_from_smiles_list(smiles_list,nbits=2048):
    fp_list = []
    for smiles in tqdm(smiles_list):
        mol = Chem.MolFromSmiles(smiles)
        fp_list.append(fp_as_array(mol,nbits))
    return fp_list

def fp_as_array(mol,n_bits=2048):
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=n_bits)
    arr = np.zeros((1,), numpy.int_)
    DataStructs.ConvertToNumpyArray(fp, arr)
    return arr
```


```python
fp_list = fp_list_from_smiles_list(porph["Smiles"]) # Get fingerprints for PCA analysis for porphyrin database !
```

      0%|          | 0/317 [00:00<?, ?it/s][00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
     27%|██▋       | 86/317 [00:00<00:00, 857.61it/s][00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
     56%|█████▋    | 179/317 [00:00<00:00, 899.52it/s][00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
     90%|████████▉ | 285/317 [00:00<00:00, 971.29it/s][00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    [00:31:16] DEPRECATION WARNING: please use MorganGenerator
    100%|██████████| 317/317 [00:00<00:00, 954.41it/s]
    


```python
#Perform principal component analysis (PCA) on the fingerprints.
pca = PCA(n_components=2)
crds = pca.fit_transform(fp_list) 
```


```python
crds_df = pd.DataFrame(crds,columns=["PC_1","PC_2"])
crds_df['is_active'] = list(porph['activity'])  
crds_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PC_1</th>
      <th>PC_2</th>
      <th>is_active</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.91</td>
      <td>2.55</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.30</td>
      <td>1.71</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.57</td>
      <td>-1.05</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.18</td>
      <td>1.80</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.77</td>
      <td>2.05</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
var = np.sum(pca.explained_variance_ratio_)
var
```




    np.float64(0.3279951006917782)




```python
ax = sns.scatterplot(data=crds_df.query("is_active == '0'"),x="PC_1",y="PC_2",color='#015482')
ax = sns.scatterplot(data=crds_df.query("is_active == '1'"),x="PC_1",y="PC_2",color='#3eaf76')
b= plt.legend(labels=['Inactive', 'Active'])
```


    
![png](output_104_0.png)
    


# Similarity Search for dataframe



```python
# Mol objects of structures for similarity search
list_mol=[]
for i in porph['Smiles']:
    mol = Chem.MolFromSmiles(i)
    list_mol.append(mol)
porph['mol']= list_mol
porph[0:3]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Molecule ChEMBL ID</th>
      <th>Molecule Name</th>
      <th>Molecule Max Phase</th>
      <th>Molecular Weight</th>
      <th>#RO5 Violations</th>
      <th>AlogP</th>
      <th>Compound Key</th>
      <th>Smiles</th>
      <th>Standard Type</th>
      <th>...</th>
      <th>Properties</th>
      <th>Action Type</th>
      <th>Standard Text Value</th>
      <th>activity_status</th>
      <th>pIC$_5$$_0$</th>
      <th>z_score</th>
      <th>activity</th>
      <th>qed</th>
      <th>fr_Al_COO</th>
      <th>mol</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>16</td>
      <td>CHEMBL268410</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1279.63</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7</td>
      <td>CC1=C(C(COC(=O)C23C[C@H]4C[C@@H](C2)C[C@@H](C3...</td>
      <td>IC50</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>5.30</td>
      <td>-0.35</td>
      <td>1</td>
      <td>0.07</td>
      <td>2</td>
      <td>&lt;rdkit.Chem.rdchem.Mol object at 0x000001BD23A...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>39</td>
      <td>CHEMBL4741802</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>813.95</td>
      <td>3.00</td>
      <td>7.97</td>
      <td>3a</td>
      <td>CCCCCCOC(C)c1c(C)c2cc3nc(c(CC(=O)N[C@@H](CC(=O...</td>
      <td>IC50</td>
      <td>...</td>
      <td>TIME = 48.0 hr</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
      <td>3.75</td>
      <td>-1.45</td>
      <td>0</td>
      <td>0.06</td>
      <td>3</td>
      <td>&lt;rdkit.Chem.rdchem.Mol object at 0x000001BD23A...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>40</td>
      <td>CHEMBL2111186</td>
      <td>TALAPORFIN</td>
      <td>3.00</td>
      <td>711.77</td>
      <td>3.00</td>
      <td>5.95</td>
      <td>Talaporfin</td>
      <td>C=Cc1c(C)c2cc3nc(c(CC(=O)N[C@@H](CC(=O)O)C(=O)...</td>
      <td>IC50</td>
      <td>...</td>
      <td>TIME = 48.0 hr</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
      <td>4.85</td>
      <td>-0.67</td>
      <td>0</td>
      <td>0.12</td>
      <td>3</td>
      <td>&lt;rdkit.Chem.rdchem.Mol object at 0x000001BD23A...</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 55 columns</p>
</div>




```python
fps= [FingerprintMols.FingerprintMol(mol) for mol in list_mol]
fps[0:3]
```




    [<rdkit.DataStructs.cDataStructs.ExplicitBitVect at 0x1bd23a36960>,
     <rdkit.DataStructs.cDataStructs.ExplicitBitVect at 0x1bd225ca9d0>,
     <rdkit.DataStructs.cDataStructs.ExplicitBitVect at 0x1bd225cab90>]




```python
list_9=porph["Molecule ChEMBL ID"].tolist()
list_9[0:3]
```




    ['CHEMBL268410', 'CHEMBL4741802', 'CHEMBL2111186']




```python
inchis = []
for n in range(len(list_mol)):
    list_mol[n].SetProp('_Name', list_9[n]) # set a title line
```


```python
size=len(list_mol)
hmap=np.empty(shape=(size,size))
table=pd.DataFrame()
for index, i in enumerate(fps):
     for jndex, j in enumerate(fps):
        similarity=DataStructs.FingerprintSimilarity(i,j)
        hmap[index,jndex]=similarity
        table.loc[list_mol[index].GetProp('_Name'),list_mol[jndex].GetProp('_Name')]=similarity

```


```python
Draw.MolsToGridImage(list_mol[0:8],molsPerRow=10,subImgSize=(150,150), legends=[y for y in list_9])

```




    
![png](output_111_0.png)
    



# HCL clustering


```python
#intersect data
linked = linkage(hmap,'single')
labelList = [mol.GetProp('_Name') for mol in list_mol]
```


```python
plt.figure(figsize=(8,15))

ax1=plt.subplot()
o=dendrogram(linked,  
            orientation='left',
            labels=labelList,
            distance_sort='descending',
            show_leaf_counts=True)

ax1.spines['left'].set_visible(False)
ax1.spines['top'].set_visible(False)
ax1.spines['right'].set_visible(False)
plt.title('Similarity clustering',fontsize=20,weight='bold')
plt.tick_params ('both',width=1,labelsize=0.1)
plt.tight_layout()
plt.grid(False)
plt.show() 
```


    
![png](output_114_0.png)
    



```python
# Extract cluster colors assigned in the dendrogram
# C0: blue, C1:Orange, C2:Green , C3:Red, C4:Purple, C5:,C6: ,C7:, C8:
# Display the clusters grouped by color along with the count of molecules in each cluster
for color, molecules in color_dict.items():
    num_molecules = len(molecules)  # Count the number of molecules in the cluster
    print(f"\033[1mCluster Color: {color}\033[0m")  # Bold text
    print(f"  Number of Molecules: {num_molecules}")
    print(f"  Molecules: {', '.join(molecules)}\n")
```

    [1mCluster Color: C1[0m
      Number of Molecules: 155
      Molecules: CHEMBL2420129, CHEMBL2420128, CHEMBL84664, CHEMBL1204020, CHEMBL1204019, CHEMBL2448393, CHEMBL2448394, CHEMBL335814, CHEMBL343554, CHEMBL2448395, CHEMBL1202375, CHEMBL216608, CHEMBL353314, CHEMBL353314, CHEMBL353314, CHEMBL438407, CHEMBL64170, CHEMBL385213, CHEMBL2326209, CHEMBL345046, CHEMBL345046, CHEMBL345046, CHEMBL385913, CHEMBL1213288, CHEMBL2171698, CHEMBL4099866, CHEMBL2171697, CHEMBL2403179, CHEMBL337559, CHEMBL2448392, CHEMBL3885145, CHEMBL3883779, CHEMBL3884511, CHEMBL4084530, CHEMBL207155, CHEMBL207155, CHEMBL207155, CHEMBL448043, CHEMBL5191770, CHEMBL379212, CHEMBL208356, CHEMBL210824, CHEMBL210423, CHEMBL507897, CHEMBL453430, CHEMBL452165, CHEMBL500801, CHEMBL511020, CHEMBL504951, CHEMBL478547, CHEMBL502433, CHEMBL503674, CHEMBL4461583, CHEMBL4588761, CHEMBL377997, CHEMBL210507, CHEMBL210267, CHEMBL210267, CHEMBL380150, CHEMBL507368, CHEMBL376934, CHEMBL210258, CHEMBL210438, CHEMBL209298, CHEMBL379609, CHEMBL2420131, CHEMBL207571, CHEMBL5208044, CHEMBL4592530, CHEMBL4449147, CHEMBL2179421, CHEMBL1202373, CHEMBL1202377, CHEMBL432374, CHEMBL432374, CHEMBL65606, CHEMBL65606, CHEMBL65606, CHEMBL65606, CHEMBL65606, CHEMBL65606, CHEMBL65606, CHEMBL138602, CHEMBL344150, CHEMBL285891, CHEMBL285891, CHEMBL221265, CHEMBL1207607, CHEMBL103555, CHEMBL103697, CHEMBL5192835, CHEMBL2170855, CHEMBL2170855, CHEMBL2170855, CHEMBL2170855, CHEMBL2420130, CHEMBL265594, CHEMBL1933797, CHEMBL3885394, CHEMBL5194142, CHEMBL2179422, CHEMBL410693, CHEMBL1076997, CHEMBL1076994, CHEMBL1076995, CHEMBL1076996, CHEMBL1076993, CHEMBL5204748, CHEMBL5179944, CHEMBL5208370, CHEMBL2158902, CHEMBL5206067, CHEMBL323147, CHEMBL320785, CHEMBL2385809, CHEMBL2385807, CHEMBL2385808, CHEMBL2420134, CHEMBL2420133, CHEMBL2420132, CHEMBL2420137, CHEMBL4778337, CHEMBL4754261, CHEMBL2179423, CHEMBL2420136, CHEMBL2420135, CHEMBL5394589, CHEMBL5416861, CHEMBL5437556, CHEMBL5401851, CHEMBL4162330, CHEMBL4176389, CHEMBL5438227, CHEMBL4173006, CHEMBL4168854, CHEMBL208614, CHEMBL3605559, CHEMBL4548859, CHEMBL4584833, CHEMBL4535457, CHEMBL4569987, CHEMBL500576, CHEMBL500576, CHEMBL500576, CHEMBL500576, CHEMBL500576, CHEMBL500576, CHEMBL515225, CHEMBL4208208, CHEMBL4746998, CHEMBL4753239, CHEMBL4786881, CHEMBL4780438, CHEMBL4742944, CHEMBL4757249
    
    [1mCluster Color: C0[0m
      Number of Molecules: 3
      Molecules: CHEMBL421734, CHEMBL1933798, CHEMBL431916
    
    [1mCluster Color: C2[0m
      Number of Molecules: 126
      Molecules: CHEMBL384612, CHEMBL217693, CHEMBL442513, CHEMBL268410, CHEMBL326831, CHEMBL408667, CHEMBL324788, CHEMBL12659, CHEMBL99196, CHEMBL329975, CHEMBL317840, CHEMBL3623244, CHEMBL1319648, CHEMBL5277612, CHEMBL4776852, CHEMBL3622614, CHEMBL3622615, CHEMBL510103, CHEMBL451898, CHEMBL446293, CHEMBL506285, CHEMBL1672412, CHEMBL1672413, CHEMBL1672414, CHEMBL3400531, CHEMBL2012578, CHEMBL3400525, CHEMBL3400528, CHEMBL520220, CHEMBL2012579, CHEMBL1672411, CHEMBL1672410, CHEMBL4437183, CHEMBL4446427, CHEMBL4569954, CHEMBL4520967, CHEMBL4439764, CHEMBL4586395, CHEMBL4591839, CHEMBL4525164, CHEMBL4444252, CHEMBL4473921, CHEMBL4796809, CHEMBL500853, CHEMBL500853, CHEMBL5080081, CHEMBL5079336, CHEMBL5090185, CHEMBL5076531, CHEMBL5089408, CHEMBL5077258, CHEMBL1908962, CHEMBL5170755, CHEMBL434263, CHEMBL4582691, CHEMBL4129037, CHEMBL4793670, CHEMBL3400530, CHEMBL3623249, CHEMBL4750985, CHEMBL4551107, CHEMBL3622612, CHEMBL4581926, CHEMBL4522270, CHEMBL4794877, CHEMBL4779570, CHEMBL4744564, CHEMBL4749260, CHEMBL4788642, CHEMBL4741802, CHEMBL3623247, CHEMBL3623246, CHEMBL2111186, CHEMBL2111186, CHEMBL3623245, CHEMBL3400524, CHEMBL3400527, CHEMBL1956500, CHEMBL1956500, CHEMBL1956500, CHEMBL4166417, CHEMBL1956500, CHEMBL1956500, CHEMBL3400526, CHEMBL2012577, CHEMBL2012580, CHEMBL3400529, CHEMBL2012581, CHEMBL3400532, CHEMBL4847361, CHEMBL4853914, CHEMBL4875074, CHEMBL4862880, CHEMBL4862910, CHEMBL4847977, CHEMBL4864643, CHEMBL4848023, CHEMBL4852895, CHEMBL4857120, CHEMBL4858999, CHEMBL4848401, CHEMBL4854588, CHEMBL4874707, CHEMBL3823273, CHEMBL3823273, CHEMBL3822710, CHEMBL3823315, CHEMBL4874760, CHEMBL4878318, CHEMBL4848756, CHEMBL3822931, CHEMBL3824050, CHEMBL3823361, CHEMBL3831301, CHEMBL372265, CHEMBL371186, CHEMBL5285922, CHEMBL4800571, CHEMBL4463327, CHEMBL1325592, CHEMBL1325592, CHEMBL1325592, CHEMBL1618319, CHEMBL2105866, CHEMBL1325592, CHEMBL1325592
    
    [1mCluster Color: C3[0m
      Number of Molecules: 6
      Molecules: CHEMBL441617, CHEMBL294514, CHEMBL407898, CHEMBL5425316, CHEMBL4062234, CHEMBL5285867
    
    [1mCluster Color: C4[0m
      Number of Molecules: 6
      Molecules: CHEMBL1288927, CHEMBL1288926, CHEMBL1289860, CHEMBL1289978, CHEMBL1290179, CHEMBL3628317
    
    [1mCluster Color: C5[0m
      Number of Molecules: 5
      Molecules: CHEMBL5177846, CHEMBL5206338, CHEMBL5194793, CHEMBL5196538, CHEMBL5190821
    
    [1mCluster Color: C6[0m
      Number of Molecules: 2
      Molecules: CHEMBL4647511, CHEMBL4646650
    
    [1mCluster Color: C7[0m
      Number of Molecules: 2
      Molecules: CHEMBL4559945, CHEMBL4546850
    
    [1mCluster Color: C8[0m
      Number of Molecules: 8
      Molecules: CHEMBL333072, CHEMBL261820, CHEMBL404940, CHEMBL263114, CHEMBL2326808, CHEMBL263115, CHEMBL405870, CHEMBL260875
    
    [1mCluster Color: C9[0m
      Number of Molecules: 4
      Molecules: CHEMBL4439092, CHEMBL4516354, CHEMBL4442099, CHEMBL4514770
    
    


```python
# Select one molecule from each cluster color
selected_molecules = {color: molecules[0] for color, molecules in color_dict.items()}

# Draw molecules for each cluster color
mols = []
titles = []
for color, mol_name in selected_molecules.items():
    mol = next((m for m in list_mol if m.GetProp('_Name') == mol_name), None)
    if mol:
        mols.append(mol)
        titles.append(f"{mol_name} ({color})")

# Display the selected molecules
img = Draw.MolsToGridImage(mols, molsPerRow=4, subImgSize=(200, 200), legends=titles) 

```


```python
img
```




    
![png](output_117_0.png)
    




```python
# Select five molecules from first two clusters

# Select 5 molecules from C1 and C2 clusters
selected_molecules = {
    "C1": color_dict.get("C1", [])[:5],  # Select first 5 molecules from C1
    "C2": color_dict.get("C2", [])[:5] ,  # Select first 5 molecules from C2
    "C3": color_dict.get("C3", [])[:5]   # Select first 5 molecules from C2
}

# Get molecule objects for selected SMILES
mols = []
titles = []
for color, mol_names in selected_molecules.items():
    for mol_name in mol_names:
        mol = next((m for m in list_mol if m.GetProp('_Name') == mol_name), None)
        if mol:
            mols.append(mol)
            titles.append(f"{mol_name} ({color})")

# Display the selected molecules
img2 = Draw.MolsToGridImage(mols, molsPerRow=5, subImgSize=(200, 200), legends=titles)


```


```python
img2
```




    
![png](output_119_0.png)
    




```python
# This will give us the clusters in order as the last plot
new_data=list(reversed(o['ivl']))

# we create a new table with the order of HCL
hmap_2=np.empty(shape=(size,size))
for index,i in enumerate(new_data):
    for jndex,j in enumerate(new_data):
        hmap_2[index,jndex]=table.loc[i].at[j]
```


```python
figure= plt.figure(figsize=(30,30))
gs1 = gridspec.GridSpec(2,7)
gs1.update(wspace=0.01)
ax1 = plt.subplot(gs1[0:-1, :2])
dendrogram(linked, orientation='left', distance_sort='descending',show_leaf_counts=True,no_labels=True)
ax1.spines['left'].set_visible(False)
ax1.spines['top'].set_visible(False)
ax1.spines['right'].set_visible(False)

ax2 = plt.subplot(gs1[0:-1,2:6])
f=ax2.imshow (hmap, cmap='RdPu', interpolation='nearest')

ax2.set_title('Fingerprint Similarity',fontsize=20,weight='bold')
ax2.set_xticks (range(len(new_data)))
ax2.set_yticks (range(len(new_data)))
ax2.set_xticklabels (new_data,rotation=90,size=8)
ax2.set_yticklabels (new_data,size=8)

ax3 = plt.subplot(gs1[0:-1,6:7])
m=plt.colorbar(f,cax=ax3,shrink=0.75,orientation='vertical',spacing='uniform',pad=0.01)
m.set_label ('Fingerprint Similarity')

plt.tick_params ('both',width=2)
plt.grid(False)
plt.plot()
plt.savefig('hcl.png', dpi=600)
[]
```




    []




    
![png](output_121_1.png)
    


# Murcko Fragments


```python
def find_terminal_atoms(mol):
    
    """ 
    This function finds terminal atoms in the structure.
    
    Args:
        mol: Mol objects 
    """
    strt = []
    for a in mol.GetAtoms():
        if len(a.GetBonds()) == 1:
            strt.append(a)
    return strt
```


```python
def top20Frequent(a):
    """ 
    This function is to assess top 20 most frequent Murcko fragments seen in the list.
 
    Args:
        a: Smile of Murcko fragment 
        
    Returns:
        Giving the 20 most frequent Murcko fragments.
    """
    freq = {}
    for num in a:
        if num in freq and len(num)>1:
            freq[num] = freq[num] + 1
        else:
            freq[num] = 1
    collection = collections.defaultdict(list)
    for e in freq:
        f = freq[e]
        collection[f].append(e)
    res = []
    count = len(a)  # the upper limit for res
    while len(res) < 10:
        if collection[count]:
            res += collection[count]
        count -= 1
    return res
```


```python
def draw_top20Frequent(sol,counting,smis):
   
    """ 
    This function draws the 20 most seen structures, legends show how many times do they appear in the list 
  
    Args:
        sol: Smile list of top 20 most frequent Murcko fragments seen in a list
        counting: Counts number of occurences of the structures in the list
        smis: MolFromSmiles to count frequencies
        v_f: Calculation of frequencies
        ls_str: String version of frequencies to make them labels
        
    Returns:
        Structure images are given with their frequencies
        
    """
  
    smis= [Chem.MolFromSmiles(solut) for solut in sol] #Chem.MolFromSmiles of Murcko fragments to depict them in images
    for mol in smis:
        rdDepictor.Compute2DCoords(mol) 
    v_f=[counting[x] for x in sol]
    ls_str = [str(x) for x in v_f]
    drawing=Draw.MolsToGridImage(smis[:5],legends=ls_str[:5],subImgSize=(250,250),molsPerRow=5,returnPNG=False)
    return drawing
```

# MurckoScaffold 


```python
# Getting Scaffold structures using MurckoScaffold function from Rdkit
list_MurckoScaffold=[]
for mol in list_mol:
    if mol:
        core_2 =Chem.MolToSmiles(MurckoScaffold.GetScaffoldForMol(mol))
        list_MurckoScaffold.append(core_2)
print(list_MurckoScaffold[0:3])
```

    ['O=C(OCC(OC(=O)C12C[C@H]3C[C@@H](C1)C[C@@H](C2)C3)C1=Cc2cc3ccc(cc4ccc(cc5nc(cc1n2)C=C5C(COC(=O)C12C[C@H]5C[C@@H](C1)C[C@@H](C2)C5)OC(=O)C12C[C@H]5C[C@@H](C1)C[C@@H](C2)C5)[nH]4)[nH]3)C12C[C@H]3C[C@@H](C1)C[C@@H](C2)C3', 'C1=Cc2cc3ccc(cc4nc(cc5ccc(cc1n2)[nH]5)CC4)[nH]3', 'C1=Cc2cc3ccc(cc4nc(cc5ccc(cc1n2)[nH]5)CC4)[nH]3']
    


```python
#Calculating frequencies of General Murcko Fragments; how many times do they occur in the list?
count_scaff = {}
for n in list_MurckoScaffold:
    count_scaff[n] = count_scaff.get(n, 0) + 1
```


```python
# Getting Smiles of top 20 most frequent Murcko Scaffolds
solution_MurckoScaffold= top20Frequent(list_MurckoScaffold)
print(solution_MurckoScaffold[0:3])
```

    ['C1=Cc2nc1c(-c1ccccc1)c1ccc([nH]1)c(-c1ccccc1)c1nc(c(-c3ccccc3)c3ccc([nH]3)c2-c2ccccc2)C=C1', 'C1=Cc2cc3ccc(cc4nc(cc5ccc(cc1n2)[nH]5)CC4)[nH]3', 'O=C1Cc2c3nc(cc4ccc(cc5nc(cc6cc1c2[nH]6)C=C5)[nH]4)CC3']
    


```python
draw_top20Frequent(solution_MurckoScaffold,count_scaff,list_MurckoScaffold)
```




    
![png](output_130_0.png)
    




```python
import pandas as pd
from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold

# Porphyrin DataFrame'in SMILES ve pIC50 sütunları
smiles_list = porph["Smiles"].tolist()
pIC50_list = porph["pIC$_5$$_0$"].tolist()

# Molekülleri RDKit formatına çevir


# Murcko Scaffold'larını hesapla
murcko_dict = {}
for mol, pIC50 in zip(list_mol, pIC50_list):
    if mol:
        murcko_smi = Chem.MolToSmiles(MurckoScaffold.GetScaffoldForMol(mol))
        if murcko_smi not in murcko_dict:
            murcko_dict[murcko_smi] = []
        murcko_dict[murcko_smi].append(pIC50)

# En sık görülen Murcko iskeletlerini al
solution_MurckoScaffold = top20Frequent(list(murcko_dict.keys()))

# İlk 3 Murcko Scaffold’un pIC50 aralıklarını bul
murcko_pIC50_ranges = {}
for scaffold in solution_MurckoScaffold[:5]:
    if scaffold in murcko_dict:
        min_pIC50 = min(murcko_dict[scaffold])
        max_pIC50 = max(murcko_dict[scaffold])
        murcko_pIC50_ranges[scaffold] = (min_pIC50, max_pIC50)

# Sonucu yazdır
print(murcko_pIC50_ranges)

```

    {'O=C(OCC(OC(=O)C12C[C@H]3C[C@@H](C1)C[C@@H](C2)C3)C1=Cc2nc1cc1nc(cc3ccc(cc4ccc(c2)[nH]4)[nH]3)C(C(COC(=O)C23C[C@H]4C[C@@H](C2)C[C@@H](C3)C4)OC(=O)C23C[C@H]4C[C@@H](C2)C[C@@H](C3)C4)=C1)C12C[C@H]3C[C@@H](C1)C[C@@H](C2)C3': (5.0, 5.0), 'C1=Cc2cc3ccc(cc4CCc(n4)cc4ccc(cc1n2)[nH]4)[nH]3': (2.3, 10.64), 'C1=Cc2nc1cc1nc(cc3ccc(cc4ccc(c2)[nH]4)[nH]3)C=C1': (7.49, 9.4), 'C1=Cc2cc3c(/C=C/c4ccc5ccccc5n4)cc(cc4CCc(n4)cc4ccc(cc1n2)[nH]4)[nH]3': (9.34, 9.34), 'C1=Cc2nc1c(-c1cc[nH+]cc1)c1nc(c(-c3cc[nH+]cc3)c3ccc([nH]3)c(-c3cc[nH+]cc3)c3ccc(c2-c2cc[nH+]cc2)[nH]3)C=C1': (0.0, 9.89)}
    


```python
len(list_murcko_mol)
```




    317




```python
pIC50_values = df_with_200_descriptors['pIC$_5$$_0$'].tolist()
```


```python
min(df_with_200_descriptors['pIC$_5$$_0$']) # min pCI50 value in db
```




    1.9




```python
max(df_with_200_descriptors['pIC$_5$$_0$'])
```




    10.4



# Bemis Murcko


```python
def BemisMurckoFramework(mol):
    """ 
    This function removes hydrogen and terminal R groups from the structure to obtain General Murcko Framework.
    It also switches all non single bonds with single bonds. 
    
    Args:
        mol: Mol objects 
        
    Returns:
        Giving mol objects after General Murcko fragmentation.
    """
    Chem.Kekulize(mol)
    only_HA = rdkit.Chem.rdmolops.RemoveHs(mol) # keep only Heavy Atoms (HA)
    rw_mol = Chem.RWMol(only_HA) # switch all HA to Carbon
    for i in range(rw_mol.GetNumAtoms()):
        rw_mol.ReplaceAtom(i, Chem.Atom(6))
    non_single_bonds = []  # switch all non single bonds to single
    for b in rw_mol.GetBonds():
        if b.GetBondType() != Chem.BondType.SINGLE:
            non_single_bonds.append(b)
    for b in non_single_bonds:
        j = b.GetBeginAtomIdx()
        k = b.GetEndAtomIdx()
        rw_mol.RemoveBond(j, k)
        rw_mol.AddBond(j, k, Chem.BondType.SINGLE)
    
    terminal_atoms = find_terminal_atoms(rw_mol) # as long as there are terminal atoms, remove them
    while terminal_atoms != []:
        for a in terminal_atoms:
            for b in a.GetBonds():
                rw_mol.RemoveBond(b.GetBeginAtomIdx(), b.GetEndAtomIdx())
            rw_mol.RemoveAtom(a.GetIdx())
        terminal_atoms = find_terminal_atoms(rw_mol)
    return rw_mol.GetMol()
```


```python
#Smiles of bemis Murcko Fragments
List_Bemis_Murcko=[]
for n in list_mol:
    if n:
        List_Bemis_Murcko.append(Chem.MolToSmiles(BemisMurckoFramework(n), kekuleSmiles=True))
print(List_Bemis_Murcko [0:3])
```

    ['C(CC(CCC12CC3CC(CC(C3)C1)C2)C1CC2CC3CCC(CC4CCC(C4)CC4CC(CC1C2)CC4C(CCCC12CC4CC(CC(C4)C1)C2)CCC12CC4CC(CC(C4)C1)C2)C3)CC12CC3CC(CC(C3)C1)C2', 'C1CC2CC1CC1CCC(C1)CC1CCC(C1)CC1CCC(C1)C2', 'C1CC2CC1CC1CCC(C1)CC1CCC(C1)CC1CCC(C1)C2']
    


```python
#Calculating frequencies of General Murcko Fragments; how many times do they occur in the list?
count_Bemis = {}
for n in List_Bemis_Murcko:
    count_Bemis[n] = count_Bemis.get(n, 0) + 1
```


```python
List_B=[i for i in count_Bemis.values()]

```


```python
# Getting Smiles of top 20 most frequent Murcko General Fragments
solution_Bemis= top20Frequent(List_Bemis_Murcko)
print(solution_Bemis)
```

    ['C1CCC(C2C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CCC2C3)CC1', 'C1CC2CC1CC1CCC(C1)CC1CCC(C1)CC1CCC(C1)C2', 'C1CC2CC1CC1CCC(C1)CC1CC3CCC(C4CCC(C2)C4)C3C1', 'C1CCC(C2C3CCC(CC4CCC(C4)C(C4CCCCC4)C4CCC(CC5CCC2C5)C4)C3)CC1', 'C.C.C.C.C1CCC(C2C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CCC2C3)CC1', 'C.C.C1CCC(C2C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CCC2C3)CC1', 'C.C.C1CCC(C2C3CCC(CC4CCC(C4)C(C4CCCCC4)C4CCC(CC5CCC2C5)C4)C3)CC1', 'C1CCC(C2C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CC(C4CC5CCCC5CC43)C(C3CCCCC3)C3CCC2C3)CC1', 'C1CCC(C2C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CCC2C3)CC1.C1CCCCC1.C1CCCCC1.C1CCCCC1.C1CCCCC1', 'C1CCC2C3CC4CCC(CC5CCC(C5)CC5CCC(C5)CC(C3)C2C1)C4', 'C1CCC(C2C3CCC(C3)C(C3CCCCC3)C3CCC(C3)C(C3CCCCC3)C3CC(CC3C3CCCC3)C(C3CCCCC3)C3CCC2C3)CC1', 'C1CCC(C2C3CCC(CC4CCC(C4)C(C4CCCCC4)C4CC(CC5CCC2C5)C2CC5CCCC5CC24)C3)CC1', 'C1CCC(CCCCC2CC3CC4CCC(CC5CCC(C5)CC5CCC(C5)CC2C3)C4)CC1', 'C1CCC2CCCC(C2)C2CCC(CCC3CCCC3CC1)CC2']
    


```python
draw_top20Frequent(solution_Bemis,count_Bemis,List_Bemis_Murcko)
```




    
![png](output_142_0.png)
    




```python
porph=porph_cleaned
```

# Machine Learning


```python
# Mol objects of structures for similarity search (Mol notation conversion needed)
porph_mol=[]
for i in porph['Smiles']:
    mol = Chem.MolFromSmiles(i)
    porph_mol.append(mol)
porph['mol']= porph_mol
porph[0:3]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Molecule ChEMBL ID</th>
      <th>Molecule Name</th>
      <th>Molecule Max Phase</th>
      <th>Molecular Weight</th>
      <th>#RO5 Violations</th>
      <th>AlogP</th>
      <th>Compound Key</th>
      <th>Smiles</th>
      <th>Standard Type</th>
      <th>...</th>
      <th>Document Journal</th>
      <th>Document Year</th>
      <th>Cell ChEMBL ID</th>
      <th>Properties</th>
      <th>Action Type</th>
      <th>Standard Text Value</th>
      <th>activity_status</th>
      <th>pIC$_5$$_0$</th>
      <th>z_score</th>
      <th>mol</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>16</td>
      <td>CHEMBL268410</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1279.63</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7</td>
      <td>CC1=C(C(COC(=O)C23C[C@H]4C[C@@H](C2)C[C@@H](C3...</td>
      <td>IC50</td>
      <td>...</td>
      <td>J Med Chem</td>
      <td>1992.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ active</td>
      <td>5.30</td>
      <td>-0.35</td>
      <td>&lt;rdkit.Chem.rdchem.Mol object at 0x000001BD391...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>39</td>
      <td>CHEMBL4741802</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>813.95</td>
      <td>3.00</td>
      <td>7.97</td>
      <td>3a</td>
      <td>CCCCCCOC(C)c1c(C)c2cc3nc(c(CC(=O)N[C@@H](CC(=O...</td>
      <td>IC50</td>
      <td>...</td>
      <td>Eur J Med Chem</td>
      <td>2020.00</td>
      <td>CHEMBL3307651</td>
      <td>TIME = 48.0 hr</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
      <td>3.75</td>
      <td>-1.45</td>
      <td>&lt;rdkit.Chem.rdchem.Mol object at 0x000001BD391...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>40</td>
      <td>CHEMBL2111186</td>
      <td>TALAPORFIN</td>
      <td>3.00</td>
      <td>711.77</td>
      <td>3.00</td>
      <td>5.95</td>
      <td>Talaporfin</td>
      <td>C=Cc1c(C)c2cc3nc(c(CC(=O)N[C@@H](CC(=O)O)C(=O)...</td>
      <td>IC50</td>
      <td>...</td>
      <td>Eur J Med Chem</td>
      <td>2020.00</td>
      <td>CHEMBL3307762</td>
      <td>TIME = 48.0 hr</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>pIC$_5$$_0$ inactive</td>
      <td>4.85</td>
      <td>-0.67</td>
      <td>&lt;rdkit.Chem.rdchem.Mol object at 0x000001BD391...</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 52 columns</p>
</div>




```python
FP = [AllChem.GetMorganFingerprintAsBitVect(mol, 2, 1024) for mol in porph.mol]
df_FP = pd.DataFrame(np.array(FP))
df_FP.head()
```

    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    [00:58:20] DEPRECATION WARNING: please use MorganGenerator
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>1014</th>
      <th>1015</th>
      <th>1016</th>
      <th>1017</th>
      <th>1018</th>
      <th>1019</th>
      <th>1020</th>
      <th>1021</th>
      <th>1022</th>
      <th>1023</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 1024 columns</p>
</div>




```python
X=df_FP
```


```python
# Assuming df_cleaned is your DataFrame and 'pIC50' is the target column
y = porph['pIC$_5$$_0$']  # Target variable
 # Features, dropping the target column
```


```python
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2)
```


```python
reg = LazyRegressor(verbose=0, ignore_warnings=False, custom_metric=None)
models_2, predictions = reg.fit(X_train, X_test, y_train, y_test)
print(models_2)
```

     57%|█████▋    | 24/42 [00:48<00:40,  2.24s/it]

    LassoLarsIC model failed to execute
    You are using LassoLarsIC in the case where the number of samples is smaller than the number of features. In this setting, getting a good estimate for the variance of the noise is not possible. Provide an estimate of the noise variance in the constructor.
    

     76%|███████▌  | 32/42 [00:51<00:05,  1.98it/s]

    RANSACRegressor model failed to execute
    `min_samples` may not be larger than number of samples: n_samples = 253.
    

    100%|██████████| 42/42 [00:58<00:00,  1.76it/s]

    XGBRegressor model failed to execute
    'super' object has no attribute '__sklearn_tags__'
    [LightGBM] [Info] Auto-choosing row-wise multi-threading, the overhead of testing was 0.001447 seconds.
    You can set `force_row_wise=true` to remove the overhead.
    And if memory is not enough, you can set `force_col_wise=true`.
    [LightGBM] [Info] Total Bins 420
    [LightGBM] [Info] Number of data points in the train set: 253, number of used features: 140
    [LightGBM] [Info] Start training from score 5.798498
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    

    100%|██████████| 42/42 [00:58<00:00,  1.40s/it]

                                                 Adjusted R-Squared  \
    Model                                                             
    Lars                          100821860608669209757634002944.00   
    LarsCV                              860234279722708254064640.00   
    SGDRegressor                                   4783775823032.37   
    KernelRidge                                                2.05   
    GaussianProcessRegressor                                   1.91   
    MLPRegressor                                               1.13   
    LinearRegression                                           1.10   
    TransformedTargetRegressor                                 1.10   
    QuantileRegressor                                          1.07   
    LassoLars                                                  1.07   
    Lasso                                                      1.07   
    DummyRegressor                                             1.07   
    ElasticNet                                                 1.07   
    OrthogonalMatchingPursuit                                  1.06   
    PassiveAggressiveRegressor                                 1.06   
    SVR                                                        1.05   
    LinearSVR                                                  1.05   
    NuSVR                                                      1.05   
    AdaBoostRegressor                                          1.05   
    OrthogonalMatchingPursuitCV                                1.05   
    Ridge                                                      1.04   
    ExtraTreeRegressor                                         1.04   
    DecisionTreeRegressor                                      1.04   
    ExtraTreesRegressor                                        1.04   
    KNeighborsRegressor                                        1.03   
    BaggingRegressor                                           1.03   
    LGBMRegressor                                              1.03   
    HistGradientBoostingRegressor                              1.03   
    LassoCV                                                    1.03   
    LassoLarsCV                                                1.03   
    BayesianRidge                                              1.03   
    HuberRegressor                                             1.03   
    RidgeCV                                                    1.03   
    GradientBoostingRegressor                                  1.03   
    ElasticNetCV                                               1.03   
    RandomForestRegressor                                      1.03   
    GammaRegressor                                             1.03   
    PoissonRegressor                                           1.03   
    TweedieRegressor                                           1.02   
    
                                                            R-Squared  \
    Model                                                               
    Lars                          -1537933461030652421508721278976.00   
    LarsCV                             -13121986393865437747085312.00   
    SGDRegressor                                   -72971564538620.33   
    KernelRidge                                                -14.97   
    GaussianProcessRegressor                                   -12.91   
    MLPRegressor                                                -0.96   
    LinearRegression                                            -0.53   
    TransformedTargetRegressor                                  -0.53   
    QuantileRegressor                                           -0.01   
    LassoLars                                                   -0.00   
    Lasso                                                       -0.00   
    DummyRegressor                                              -0.00   
    ElasticNet                                                  -0.00   
    OrthogonalMatchingPursuit                                    0.04   
    PassiveAggressiveRegressor                                   0.11   
    SVR                                                          0.23   
    LinearSVR                                                    0.23   
    NuSVR                                                        0.23   
    AdaBoostRegressor                                            0.26   
    OrthogonalMatchingPursuitCV                                  0.28   
    Ridge                                                        0.31   
    ExtraTreeRegressor                                           0.32   
    DecisionTreeRegressor                                        0.36   
    ExtraTreesRegressor                                          0.41   
    KNeighborsRegressor                                          0.47   
    BaggingRegressor                                             0.51   
    LGBMRegressor                                                0.53   
    HistGradientBoostingRegressor                                0.53   
    LassoCV                                                      0.53   
    LassoLarsCV                                                  0.54   
    BayesianRidge                                                0.54   
    HuberRegressor                                               0.55   
    RidgeCV                                                      0.56   
    GradientBoostingRegressor                                    0.56   
    ElasticNetCV                                                 0.57   
    RandomForestRegressor                                        0.58   
    GammaRegressor                                               0.61   
    PoissonRegressor                                             0.61   
    TweedieRegressor                                             0.63   
    
                                                 RMSE  Time Taken  
    Model                                                          
    Lars                          1896419890087486.00        0.34  
    LarsCV                           5539435631086.85        3.25  
    SGDRegressor                          13062988.89        0.13  
    KernelRidge                                  6.11        0.06  
    GaussianProcessRegressor                     5.70        0.12  
    MLPRegressor                                 2.14        0.87  
    LinearRegression                             1.89        0.12  
    TransformedTargetRegressor                   1.89        2.56  
    QuantileRegressor                            1.53        0.53  
    LassoLars                                    1.53        0.04  
    Lasso                                        1.53        0.04  
    DummyRegressor                               1.53        0.03  
    ElasticNet                                   1.53        0.08  
    OrthogonalMatchingPursuit                    1.50        0.13  
    PassiveAggressiveRegressor                   1.44        0.13  
    SVR                                          1.34        0.42  
    LinearSVR                                    1.34        0.62  
    NuSVR                                        1.34        0.15  
    AdaBoostRegressor                            1.32        0.23  
    OrthogonalMatchingPursuitCV                  1.29        0.34  
    Ridge                                        1.27        0.12  
    ExtraTreeRegressor                           1.26        0.10  
    DecisionTreeRegressor                        1.23        0.05  
    ExtraTreesRegressor                          1.18        1.48  
    KNeighborsRegressor                          1.12        0.23  
    BaggingRegressor                             1.07        0.18  
    LGBMRegressor                                1.05        0.20  
    HistGradientBoostingRegressor                1.05        1.98  
    LassoCV                                      1.05       21.58  
    LassoLarsCV                                  1.04        0.54  
    BayesianRidge                                1.04        0.22  
    HuberRegressor                               1.03        0.26  
    RidgeCV                                      1.01        1.51  
    GradientBoostingRegressor                    1.01        0.55  
    ElasticNetCV                                 1.00       16.52  
    RandomForestRegressor                        0.99        1.97  
    GammaRegressor                               0.96        0.38  
    PoissonRegressor                             0.95        0.11  
    TweedieRegressor                             0.93        0.11  
    

    
    


```python
models_2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Adjusted R-Squared</th>
      <th>R-Squared</th>
      <th>RMSE</th>
      <th>Time Taken</th>
    </tr>
    <tr>
      <th>Model</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Lars</th>
      <td>100821860608669209757634002944.00</td>
      <td>-1537933461030652421508721278976.00</td>
      <td>1896419890087486.00</td>
      <td>0.34</td>
    </tr>
    <tr>
      <th>LarsCV</th>
      <td>860234279722708254064640.00</td>
      <td>-13121986393865437747085312.00</td>
      <td>5539435631086.85</td>
      <td>3.25</td>
    </tr>
    <tr>
      <th>SGDRegressor</th>
      <td>4783775823032.37</td>
      <td>-72971564538620.33</td>
      <td>13062988.89</td>
      <td>0.13</td>
    </tr>
    <tr>
      <th>KernelRidge</th>
      <td>2.05</td>
      <td>-14.97</td>
      <td>6.11</td>
      <td>0.06</td>
    </tr>
    <tr>
      <th>GaussianProcessRegressor</th>
      <td>1.91</td>
      <td>-12.91</td>
      <td>5.70</td>
      <td>0.12</td>
    </tr>
    <tr>
      <th>MLPRegressor</th>
      <td>1.13</td>
      <td>-0.96</td>
      <td>2.14</td>
      <td>0.87</td>
    </tr>
    <tr>
      <th>LinearRegression</th>
      <td>1.10</td>
      <td>-0.53</td>
      <td>1.89</td>
      <td>0.12</td>
    </tr>
    <tr>
      <th>TransformedTargetRegressor</th>
      <td>1.10</td>
      <td>-0.53</td>
      <td>1.89</td>
      <td>2.56</td>
    </tr>
    <tr>
      <th>QuantileRegressor</th>
      <td>1.07</td>
      <td>-0.01</td>
      <td>1.53</td>
      <td>0.53</td>
    </tr>
    <tr>
      <th>LassoLars</th>
      <td>1.07</td>
      <td>-0.00</td>
      <td>1.53</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>Lasso</th>
      <td>1.07</td>
      <td>-0.00</td>
      <td>1.53</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>DummyRegressor</th>
      <td>1.07</td>
      <td>-0.00</td>
      <td>1.53</td>
      <td>0.03</td>
    </tr>
    <tr>
      <th>ElasticNet</th>
      <td>1.07</td>
      <td>-0.00</td>
      <td>1.53</td>
      <td>0.08</td>
    </tr>
    <tr>
      <th>OrthogonalMatchingPursuit</th>
      <td>1.06</td>
      <td>0.04</td>
      <td>1.50</td>
      <td>0.13</td>
    </tr>
    <tr>
      <th>PassiveAggressiveRegressor</th>
      <td>1.06</td>
      <td>0.11</td>
      <td>1.44</td>
      <td>0.13</td>
    </tr>
    <tr>
      <th>SVR</th>
      <td>1.05</td>
      <td>0.23</td>
      <td>1.34</td>
      <td>0.42</td>
    </tr>
    <tr>
      <th>LinearSVR</th>
      <td>1.05</td>
      <td>0.23</td>
      <td>1.34</td>
      <td>0.62</td>
    </tr>
    <tr>
      <th>NuSVR</th>
      <td>1.05</td>
      <td>0.23</td>
      <td>1.34</td>
      <td>0.15</td>
    </tr>
    <tr>
      <th>AdaBoostRegressor</th>
      <td>1.05</td>
      <td>0.26</td>
      <td>1.32</td>
      <td>0.23</td>
    </tr>
    <tr>
      <th>OrthogonalMatchingPursuitCV</th>
      <td>1.05</td>
      <td>0.28</td>
      <td>1.29</td>
      <td>0.34</td>
    </tr>
    <tr>
      <th>Ridge</th>
      <td>1.04</td>
      <td>0.31</td>
      <td>1.27</td>
      <td>0.12</td>
    </tr>
    <tr>
      <th>ExtraTreeRegressor</th>
      <td>1.04</td>
      <td>0.32</td>
      <td>1.26</td>
      <td>0.10</td>
    </tr>
    <tr>
      <th>DecisionTreeRegressor</th>
      <td>1.04</td>
      <td>0.36</td>
      <td>1.23</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>ExtraTreesRegressor</th>
      <td>1.04</td>
      <td>0.41</td>
      <td>1.18</td>
      <td>1.48</td>
    </tr>
    <tr>
      <th>KNeighborsRegressor</th>
      <td>1.03</td>
      <td>0.47</td>
      <td>1.12</td>
      <td>0.23</td>
    </tr>
    <tr>
      <th>BaggingRegressor</th>
      <td>1.03</td>
      <td>0.51</td>
      <td>1.07</td>
      <td>0.18</td>
    </tr>
    <tr>
      <th>LGBMRegressor</th>
      <td>1.03</td>
      <td>0.53</td>
      <td>1.05</td>
      <td>0.20</td>
    </tr>
    <tr>
      <th>HistGradientBoostingRegressor</th>
      <td>1.03</td>
      <td>0.53</td>
      <td>1.05</td>
      <td>1.98</td>
    </tr>
    <tr>
      <th>LassoCV</th>
      <td>1.03</td>
      <td>0.53</td>
      <td>1.05</td>
      <td>21.58</td>
    </tr>
    <tr>
      <th>LassoLarsCV</th>
      <td>1.03</td>
      <td>0.54</td>
      <td>1.04</td>
      <td>0.54</td>
    </tr>
    <tr>
      <th>BayesianRidge</th>
      <td>1.03</td>
      <td>0.54</td>
      <td>1.04</td>
      <td>0.22</td>
    </tr>
    <tr>
      <th>HuberRegressor</th>
      <td>1.03</td>
      <td>0.55</td>
      <td>1.03</td>
      <td>0.26</td>
    </tr>
    <tr>
      <th>RidgeCV</th>
      <td>1.03</td>
      <td>0.56</td>
      <td>1.01</td>
      <td>1.51</td>
    </tr>
    <tr>
      <th>GradientBoostingRegressor</th>
      <td>1.03</td>
      <td>0.56</td>
      <td>1.01</td>
      <td>0.55</td>
    </tr>
    <tr>
      <th>ElasticNetCV</th>
      <td>1.03</td>
      <td>0.57</td>
      <td>1.00</td>
      <td>16.52</td>
    </tr>
    <tr>
      <th>RandomForestRegressor</th>
      <td>1.03</td>
      <td>0.58</td>
      <td>0.99</td>
      <td>1.97</td>
    </tr>
    <tr>
      <th>GammaRegressor</th>
      <td>1.03</td>
      <td>0.61</td>
      <td>0.96</td>
      <td>0.38</td>
    </tr>
    <tr>
      <th>PoissonRegressor</th>
      <td>1.03</td>
      <td>0.61</td>
      <td>0.95</td>
      <td>0.11</td>
    </tr>
    <tr>
      <th>TweedieRegressor</th>
      <td>1.02</td>
      <td>0.63</td>
      <td>0.93</td>
      <td>0.11</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.model_selection import cross_val_score

from sklearn.linear_model import TweedieRegressor
model =TweedieRegressor()

# Perform 5-fold cross-validation
scores = cross_val_score(model, X_train, y_train, cv=5, scoring='r2')

# Print mean R² score
print(f"Mean R² score from 5-fold CV: {scores.mean():.3f}")
```

    Mean R² score from 5-fold CV: 0.215
    

# Classification (Active-Non_active)


```python
y = porph['activity'] 
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```


```python
# LazyPredict sınıflandırıcıyı başlat ve eğit
clf = LazyClassifier(verbose=0, ignore_warnings=True, custom_metric=None)
models, predictions = clf.fit(X_train, X_test, y_train, y_test)

# Sonuçları yazdır
print(models)
```

    100%|██████████| 32/32 [00:03<00:00,  8.13it/s]

    [LightGBM] [Info] Number of positive: 165, number of negative: 88
    [LightGBM] [Info] Auto-choosing row-wise multi-threading, the overhead of testing was 0.001149 seconds.
    You can set `force_row_wise=true` to remove the overhead.
    And if memory is not enough, you can set `force_col_wise=true`.
    [LightGBM] [Info] Total Bins 432
    [LightGBM] [Info] Number of data points in the train set: 253, number of used features: 144
    [LightGBM] [Info] [binary:BoostFromScore]: pavg=0.652174 -> initscore=0.628609
    [LightGBM] [Info] Start training from score 0.628609
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
                                   Accuracy  Balanced Accuracy  ROC AUC  F1 Score  \
    Model                                                                           
    Perceptron                         0.81               0.80      NaN      0.82   
    LogisticRegression                 0.83               0.80     0.80      0.83   
    ExtraTreesClassifier               0.80               0.77     0.77      0.80   
    KNeighborsClassifier               0.72               0.77     0.77      0.73   
    RandomForestClassifier             0.81               0.77     0.77      0.81   
    PassiveAggressiveClassifier        0.78               0.76      NaN      0.79   
    NearestCentroid                    0.69               0.75     0.75      0.70   
    BernoulliNB                        0.66               0.71      NaN      0.67   
    BaggingClassifier                  0.75               0.71     0.71      0.75   
    DecisionTreeClassifier             0.73               0.70     0.70      0.74   
    LGBMClassifier                     0.73               0.70     0.70      0.74   
    SGDClassifier                      0.78               0.70      NaN      0.77   
    RidgeClassifier                    0.72               0.69      NaN      0.73   
    RidgeClassifierCV                  0.77               0.68      NaN      0.76   
    NuSVC                              0.75               0.66     0.66      0.74   
    QuadraticDiscriminantAnalysis      0.55               0.65     0.65      0.56   
    LinearSVC                          0.64               0.63     0.63      0.66   
    GaussianNB                         0.62               0.62      NaN      0.64   
    ExtraTreeClassifier                0.67               0.62     0.62      0.68   
    AdaBoostClassifier                 0.64               0.61     0.61      0.66   
    LinearDiscriminantAnalysis         0.61               0.59      NaN      0.63   
    SVC                                0.72               0.57     0.57      0.68   
    CalibratedClassifierCV             0.72               0.52     0.52      0.63   
    LabelSpreading                     0.31               0.50     0.50      0.21   
    LabelPropagation                   0.31               0.50     0.50      0.21   
    DummyClassifier                    0.72               0.50      NaN      0.60   
    
                                   Time Taken  
    Model                                      
    Perceptron                           0.04  
    LogisticRegression                   0.05  
    ExtraTreesClassifier                 0.26  
    KNeighborsClassifier                 0.04  
    RandomForestClassifier               0.30  
    PassiveAggressiveClassifier          0.05  
    NearestCentroid                      0.08  
    BernoulliNB                          0.04  
    BaggingClassifier                    0.21  
    DecisionTreeClassifier               0.05  
    LGBMClassifier                       0.16  
    SGDClassifier                        0.05  
    RidgeClassifier                      0.04  
    RidgeClassifierCV                    0.06  
    NuSVC                                0.08  
    QuadraticDiscriminantAnalysis        0.13  
    LinearSVC                            0.34  
    GaussianNB                           0.04  
    ExtraTreeClassifier                  0.05  
    AdaBoostClassifier                   0.33  
    LinearDiscriminantAnalysis           0.09  
    SVC                                  0.07  
    CalibratedClassifierCV               1.11  
    LabelSpreading                       0.10  
    LabelPropagation                     0.04  
    DummyClassifier                      0.04  
    

    
    


```python
models
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Accuracy</th>
      <th>Balanced Accuracy</th>
      <th>ROC AUC</th>
      <th>F1 Score</th>
      <th>Time Taken</th>
    </tr>
    <tr>
      <th>Model</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Perceptron</th>
      <td>0.81</td>
      <td>0.80</td>
      <td>NaN</td>
      <td>0.82</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>LogisticRegression</th>
      <td>0.83</td>
      <td>0.80</td>
      <td>0.80</td>
      <td>0.83</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>ExtraTreesClassifier</th>
      <td>0.80</td>
      <td>0.77</td>
      <td>0.77</td>
      <td>0.80</td>
      <td>0.26</td>
    </tr>
    <tr>
      <th>KNeighborsClassifier</th>
      <td>0.72</td>
      <td>0.77</td>
      <td>0.77</td>
      <td>0.73</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>RandomForestClassifier</th>
      <td>0.81</td>
      <td>0.77</td>
      <td>0.77</td>
      <td>0.81</td>
      <td>0.30</td>
    </tr>
    <tr>
      <th>PassiveAggressiveClassifier</th>
      <td>0.78</td>
      <td>0.76</td>
      <td>NaN</td>
      <td>0.79</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>NearestCentroid</th>
      <td>0.69</td>
      <td>0.75</td>
      <td>0.75</td>
      <td>0.70</td>
      <td>0.08</td>
    </tr>
    <tr>
      <th>BernoulliNB</th>
      <td>0.66</td>
      <td>0.71</td>
      <td>NaN</td>
      <td>0.67</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>BaggingClassifier</th>
      <td>0.75</td>
      <td>0.71</td>
      <td>0.71</td>
      <td>0.75</td>
      <td>0.21</td>
    </tr>
    <tr>
      <th>DecisionTreeClassifier</th>
      <td>0.73</td>
      <td>0.70</td>
      <td>0.70</td>
      <td>0.74</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>LGBMClassifier</th>
      <td>0.73</td>
      <td>0.70</td>
      <td>0.70</td>
      <td>0.74</td>
      <td>0.16</td>
    </tr>
    <tr>
      <th>SGDClassifier</th>
      <td>0.78</td>
      <td>0.70</td>
      <td>NaN</td>
      <td>0.77</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>RidgeClassifier</th>
      <td>0.72</td>
      <td>0.69</td>
      <td>NaN</td>
      <td>0.73</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>RidgeClassifierCV</th>
      <td>0.77</td>
      <td>0.68</td>
      <td>NaN</td>
      <td>0.76</td>
      <td>0.06</td>
    </tr>
    <tr>
      <th>NuSVC</th>
      <td>0.75</td>
      <td>0.66</td>
      <td>0.66</td>
      <td>0.74</td>
      <td>0.08</td>
    </tr>
    <tr>
      <th>QuadraticDiscriminantAnalysis</th>
      <td>0.55</td>
      <td>0.65</td>
      <td>0.65</td>
      <td>0.56</td>
      <td>0.13</td>
    </tr>
    <tr>
      <th>LinearSVC</th>
      <td>0.64</td>
      <td>0.63</td>
      <td>0.63</td>
      <td>0.66</td>
      <td>0.34</td>
    </tr>
    <tr>
      <th>GaussianNB</th>
      <td>0.62</td>
      <td>0.62</td>
      <td>NaN</td>
      <td>0.64</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>ExtraTreeClassifier</th>
      <td>0.67</td>
      <td>0.62</td>
      <td>0.62</td>
      <td>0.68</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>AdaBoostClassifier</th>
      <td>0.64</td>
      <td>0.61</td>
      <td>0.61</td>
      <td>0.66</td>
      <td>0.33</td>
    </tr>
    <tr>
      <th>LinearDiscriminantAnalysis</th>
      <td>0.61</td>
      <td>0.59</td>
      <td>NaN</td>
      <td>0.63</td>
      <td>0.09</td>
    </tr>
    <tr>
      <th>SVC</th>
      <td>0.72</td>
      <td>0.57</td>
      <td>0.57</td>
      <td>0.68</td>
      <td>0.07</td>
    </tr>
    <tr>
      <th>CalibratedClassifierCV</th>
      <td>0.72</td>
      <td>0.52</td>
      <td>0.52</td>
      <td>0.63</td>
      <td>1.11</td>
    </tr>
    <tr>
      <th>LabelSpreading</th>
      <td>0.31</td>
      <td>0.50</td>
      <td>0.50</td>
      <td>0.21</td>
      <td>0.10</td>
    </tr>
    <tr>
      <th>LabelPropagation</th>
      <td>0.31</td>
      <td>0.50</td>
      <td>0.50</td>
      <td>0.21</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>DummyClassifier</th>
      <td>0.72</td>
      <td>0.50</td>
      <td>NaN</td>
      <td>0.60</td>
      <td>0.04</td>
    </tr>
  </tbody>
</table>
</div>




```python
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier

# Initialize the model
model = RandomForestClassifier(n_estimators=100)

# Perform cross-validation
scores = cross_val_score(model, X, y, cv=5)  # 5-fold cross-validation

# Output the results
print("Cross-Validation Scores:", scores)
print("Mean Score:", np.mean(scores))
```

    Cross-Validation Scores: [0.796875   0.671875   0.79365079 0.74603175 0.6031746 ]
    Mean Score: 0.7223214285714286
    


```python
model = LogisticRegression()

# Perform 5-fold cross-validation
scores = cross_val_score(model, X, y, cv=5)

# Output results
print("Cross-Validation Scores:", scores)
print("Mean Score:", np.mean(scores))
```

    Cross-Validation Scores: [0.75       0.65625    0.74603175 0.6984127  0.6031746 ]
    Mean Score: 0.6907738095238096
    


```python
# 
plt.figure(figsize=(5, 10))
sns.set_theme(style="whitegrid")
ax = sns.barplot(y=models.index, x="Accuracy", data=models)
ax.set(xlim=(0, 1))
```




    [(0.0, 1.0)]




    
![png](output_160_1.png)
    


# TUMOR RESPONSE


```python
porph = pd.read_csv('porphyrin.csv')
```


```python
t_res=porph[(porph['Standard Type']== 'Tumor response') | (porph['Standard Type']=='Tumor cure')]
```


```python
t_res=t_res[~t_res.duplicated(['Molecule ChEMBL ID', 'Document ChEMBL ID'], keep=False)]
t_res['Standard Value'].fillna(0, inplace = True)
```


```python
t_res.sort_values(by=['Standard Value'], ascending=False, inplace=True)
```


```python
len(t_res)
```




    11




```python
x=plt.bar(t_res['Molecule ChEMBL ID'], t_res['Standard Value'], align='center',color ="#DA70D6"
)
plt.xticks(rotation=40,fontsize='9',horizontalalignment='right')
plt.yticks(fontsize='9')
plt.xlabel('ChEMBL IDs of Molecules', fontweight='bold', color='black',
   fontsize='11', horizontalalignment='center')
plt.ylabel('Tumor Response % ', fontweight='bold', color='black',
   fontsize='11', horizontalalignment='center')
plt.savefig('tumor_resp.png', dpi=600)
plt.grid(False);
```


    
![png](output_167_0.png)
    



```python

tres_mol=[]
for i in t_res['Smiles']:
    mol = Chem.MolFromSmiles(i)
    tres_mol.append(mol)

```


```python
Draw.MolsToGridImage(tres_mol,molsPerRow=4,subImgSize=(150,150))
```




    
![png](output_169_0.png)
    




```python
freq1=tres_mol[4]
rdDepictor.Compute2DCoords(freq1)
```




    0




```python
freq1
```




    
![png](output_171_0.png)
    




```python
img = Draw.MolToImage(freq1, size=(300, 300)) 
```


```python
img
```




    
![png](output_173_0.png)
    


